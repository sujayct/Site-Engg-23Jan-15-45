import { supabase } from '../lib/supabase';

export interface CompanyProfile {
  id: string;
  company_name: string;
  brand_name: string;
  logo_url: string | null;
  primary_color: string;
  secondary_color: string;
  support_email: string;
  contact_number: string;
  address: string;
  created_at: string;
  updated_at: string;
  updated_by: string | null;
}

export interface CompanyProfileInput {
  company_name: string;
  brand_name: string;
  logo_url?: string | null;
  primary_color: string;
  secondary_color: string;
  support_email: string;
  contact_number: string;
  address: string;
}

class CompanyProfileService {
  async getCompanyProfile(): Promise<CompanyProfile | null> {
    const { data, error } = await supabase
      .from('company_profiles')
      .select('*')
      .order('created_at', { ascending: false })
      .limit(1)
      .maybeSingle();

    if (error) {
      console.error('Error fetching company profile:', error);
      throw error;
    }

    return data;
  }

  async createCompanyProfile(profile: CompanyProfileInput, userId: string): Promise<CompanyProfile> {
    const { data, error } = await supabase
      .from('company_profiles')
      .insert({
        ...profile,
        updated_by: userId,
      })
      .select()
      .single();

    if (error) {
      console.error('Error creating company profile:', error);
      throw error;
    }

    return data;
  }

  async updateCompanyProfile(id: string, profile: Partial<CompanyProfileInput>, userId: string): Promise<CompanyProfile> {
    const { data, error } = await supabase
      .from('company_profiles')
      .update({
        ...profile,
        updated_by: userId,
        updated_at: new Date().toISOString(),
      })
      .eq('id', id)
      .select()
      .single();

    if (error) {
      console.error('Error updating company profile:', error);
      throw error;
    }

    return data;
  }

  async uploadLogo(file: File): Promise<string> {
    const fileExt = file.name.split('.').pop();
    const fileName = `logo-${Date.now()}.${fileExt}`;
    const filePath = `company-logos/${fileName}`;

    const { error: uploadError } = await supabase.storage
      .from('company-assets')
      .upload(filePath, file, {
        cacheControl: '3600',
        upsert: false,
      });

    if (uploadError) {
      console.error('Error uploading logo:', uploadError);
      throw uploadError;
    }

    const { data: { publicUrl } } = supabase.storage
      .from('company-assets')
      .getPublicUrl(filePath);

    return publicUrl;
  }

  async deleteLogo(logoUrl: string): Promise<void> {
    if (!logoUrl) return;

    try {
      const urlParts = logoUrl.split('/company-assets/');
      if (urlParts.length < 2) return;

      const filePath = urlParts[1];

      const { error } = await supabase.storage
        .from('company-assets')
        .remove([filePath]);

      if (error) {
        console.error('Error deleting logo:', error);
      }
    } catch (error) {
      console.error('Error processing logo deletion:', error);
    }
  }

  validateLogoFile(file: File): { valid: boolean; error?: string } {
    const allowedTypes = ['image/png', 'image/jpeg', 'image/jpg'];
    const maxSize = 5 * 1024 * 1024;

    if (!allowedTypes.includes(file.type)) {
      return {
        valid: false,
        error: 'Invalid file type. Please upload PNG or JPG images only.',
      };
    }

    if (file.size > maxSize) {
      return {
        valid: false,
        error: 'File size too large. Maximum size is 5MB.',
      };
    }

    return { valid: true };
  }

  isValidHexColor(color: string): boolean {
    return /^#[0-9A-F]{6}$/i.test(color);
  }

  isValidEmail(email: string): boolean {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
  }
}

export const companyProfileService = new CompanyProfileService();
