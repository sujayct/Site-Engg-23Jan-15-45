import { supabase } from '../lib/supabase';
import type { CheckIn } from '../types';

export const checkInService = {
  async getTodayCheckIn(engineerId: string): Promise<CheckIn | null> {
    const today = new Date().toISOString().split('T')[0];
    const { data, error } = await supabase
      .from('check_ins')
      .select('*')
      .eq('engineer_id', engineerId)
      .eq('date', today)
      .maybeSingle();

    if (error) {
      console.error('Error fetching today check-in:', error);
      return null;
    }

    return data ? {
      id: data.id,
      engineerId: data.engineer_id,
      checkInTime: data.check_in_time,
      checkOutTime: data.check_out_time,
      latitude: data.latitude ? parseFloat(data.latitude) : undefined,
      longitude: data.longitude ? parseFloat(data.longitude) : undefined,
      locationName: data.location_name,
      date: data.date,
      createdAt: data.created_at
    } : null;
  },

  async createCheckIn(
    engineerId: string,
    latitude?: number,
    longitude?: number,
    locationName?: string,
    siteId?: string
  ): Promise<CheckIn> {
    const now = new Date();
    const today = now.toISOString().split('T')[0];

    const { data, error } = await supabase
      .from('check_ins')
      .insert({
        engineer_id: engineerId,
        check_in_time: now.toISOString(),
        latitude,
        longitude,
        location_name: locationName,
        date: today
      })
      .select()
      .single();

    if (error) {
      throw new Error(error.message);
    }

    return {
      id: data.id,
      engineerId: data.engineer_id,
      checkInTime: data.check_in_time,
      checkOutTime: data.check_out_time,
      latitude: data.latitude ? parseFloat(data.latitude) : undefined,
      longitude: data.longitude ? parseFloat(data.longitude) : undefined,
      locationName: data.location_name,
      date: data.date,
      createdAt: data.created_at
    };
  },

  async checkOut(checkInId: string): Promise<void> {
    const { error } = await supabase
      .from('check_ins')
      .update({ check_out_time: new Date().toISOString() })
      .eq('id', checkInId);

    if (error) {
      throw new Error(error.message);
    }
  },

  async getCheckIns(engineerId: string): Promise<CheckIn[]> {
    const { data, error } = await supabase
      .from('check_ins')
      .select('*')
      .eq('engineer_id', engineerId)
      .order('date', { ascending: false });

    if (error) {
      console.error('Error fetching check-ins:', error);
      return [];
    }

    return (data || []).map(item => ({
      id: item.id,
      engineerId: item.engineer_id,
      checkInTime: item.check_in_time,
      checkOutTime: item.check_out_time,
      latitude: item.latitude ? parseFloat(item.latitude) : undefined,
      longitude: item.longitude ? parseFloat(item.longitude) : undefined,
      locationName: item.location_name,
      date: item.date,
      createdAt: item.created_at
    }));
  },

  async getAllCheckIns(): Promise<CheckIn[]> {
    const { data, error } = await supabase
      .from('check_ins')
      .select(`
        *,
        profiles:engineer_id (
          full_name,
          email
        )
      `)
      .order('date', { ascending: false });

    if (error) {
      console.error('Error fetching all check-ins:', error);
      return [];
    }

    return (data || []).map(item => ({
      id: item.id,
      engineerId: item.engineer_id,
      engineerName: item.profiles?.full_name,
      checkInTime: item.check_in_time,
      checkOutTime: item.check_out_time,
      latitude: item.latitude ? parseFloat(item.latitude) : undefined,
      longitude: item.longitude ? parseFloat(item.longitude) : undefined,
      locationName: item.location_name,
      date: item.date,
      createdAt: item.created_at
    }));
  }
};
