import { supabase } from '../lib/supabase';

export interface UserProfile {
  id: string;
  email: string;
  full_name: string;
  role: 'admin' | 'engineer' | 'hr' | 'client';
  phone: string | null;
  designation: string | null;
  profile_photo_url: string | null;
  mobile_number: string | null;
  alternate_number: string | null;
  personal_email: string | null;
  address_line1: string | null;
  address_line2: string | null;
  city: string | null;
  state: string | null;
  country: string | null;
  pincode: string | null;
  date_of_birth: string | null;
  gender: string | null;
  years_of_experience: number | null;
  skills: string | null;
  reporting_manager: string | null;
  linkedin_url: string | null;
  portfolio_url: string | null;
  created_at: string;
  updated_at: string;
}

export interface ProfileUpdateInput {
  full_name?: string;
  phone?: string;
  designation?: string;
  profile_photo_url?: string;
  mobile_number?: string;
  alternate_number?: string;
  personal_email?: string;
  address_line1?: string;
  address_line2?: string;
  city?: string;
  state?: string;
  country?: string;
  pincode?: string;
  date_of_birth?: string;
  gender?: string;
  years_of_experience?: number;
  skills?: string;
  reporting_manager?: string;
  linkedin_url?: string;
  portfolio_url?: string;
}

class ProfileService {
  async getProfile(userId: string): Promise<UserProfile | null> {
    const { data, error } = await supabase
      .from('profiles')
      .select('*')
      .eq('id', userId)
      .maybeSingle();

    if (error) {
      console.error('Error fetching profile:', error);
      throw error;
    }

    return data;
  }

  async getMyProfile(): Promise<UserProfile | null> {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return null;

    return this.getProfile(user.id);
  }

  async getAllEngineers(): Promise<UserProfile[]> {
    const { data, error } = await supabase
      .from('profiles')
      .select('*')
      .eq('role', 'engineer')
      .order('full_name');

    if (error) {
      console.error('Error fetching engineers:', error);
      throw error;
    }

    return data || [];
  }

  async updateProfile(userId: string, updates: ProfileUpdateInput): Promise<UserProfile> {
    const { data, error } = await supabase
      .from('profiles')
      .update({
        ...updates,
        updated_at: new Date().toISOString(),
      })
      .eq('id', userId)
      .select()
      .single();

    if (error) {
      console.error('Error updating profile:', error);
      throw error;
    }

    return data;
  }

  async updateMyProfile(updates: ProfileUpdateInput): Promise<UserProfile> {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) throw new Error('Not authenticated');

    return this.updateProfile(user.id, updates);
  }

  async uploadProfilePhoto(file: File, userId: string): Promise<string> {
    const fileExt = file.name.split('.').pop();
    const fileName = `profile-${userId}-${Date.now()}.${fileExt}`;
    const filePath = `profile-photos/${fileName}`;

    const { error: uploadError } = await supabase.storage
      .from('user-assets')
      .upload(filePath, file, {
        cacheControl: '3600',
        upsert: true,
      });

    if (uploadError) {
      console.error('Error uploading profile photo:', uploadError);
      throw uploadError;
    }

    const { data: { publicUrl } } = supabase.storage
      .from('user-assets')
      .getPublicUrl(filePath);

    return publicUrl;
  }

  async deleteProfilePhoto(photoUrl: string): Promise<void> {
    if (!photoUrl) return;

    try {
      const urlParts = photoUrl.split('/user-assets/');
      if (urlParts.length < 2) return;

      const filePath = urlParts[1];

      const { error } = await supabase.storage
        .from('user-assets')
        .remove([filePath]);

      if (error) {
        console.error('Error deleting profile photo:', error);
      }
    } catch (error) {
      console.error('Error processing photo deletion:', error);
    }
  }

  validateProfilePhoto(file: File): { valid: boolean; error?: string } {
    const allowedTypes = ['image/png', 'image/jpeg', 'image/jpg'];
    const maxSize = 2 * 1024 * 1024;

    if (!allowedTypes.includes(file.type)) {
      return {
        valid: false,
        error: 'Invalid file type. Please upload PNG or JPG images only.',
      };
    }

    if (file.size > maxSize) {
      return {
        valid: false,
        error: 'File size too large. Maximum size is 2MB.',
      };
    }

    return { valid: true };
  }

  isValidEmail(email: string): boolean {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
  }

  isValidURL(url: string): boolean {
    try {
      new URL(url);
      return true;
    } catch {
      return false;
    }
  }

  async getManagersList(): Promise<{ id: string; name: string }[]> {
    const { data, error } = await supabase
      .from('profiles')
      .select('id, full_name')
      .in('role', ['admin', 'hr'])
      .order('full_name');

    if (error) {
      console.error('Error fetching managers:', error);
      return [];
    }

    return data.map(m => ({ id: m.id, name: m.full_name }));
  }
}

export const profileService = new ProfileService();
