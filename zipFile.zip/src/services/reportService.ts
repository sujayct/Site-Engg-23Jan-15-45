import { supabase } from '../lib/supabase';
import type { DailyReport } from '../types';

export const reportService = {
  async createReport(
    engineerId: string,
    clientId: string,
    workDone: string,
    issues?: string,
    siteId?: string,
    hoursWorked?: number
  ): Promise<DailyReport> {
    const today = new Date().toISOString().split('T')[0];

    const { data, error } = await supabase
      .from('daily_reports')
      .insert({
        engineer_id: engineerId,
        client_id: clientId,
        site_id: siteId,
        report_date: today,
        work_done: workDone,
        issues: issues || null
      })
      .select(`
        *,
        clients (name),
        sites (name),
        profiles:engineer_id (full_name)
      `)
      .single();

    if (error) {
      throw new Error(error.message);
    }

    return {
      id: data.id,
      engineerId: data.engineer_id,
      engineerName: data.profiles?.full_name,
      clientId: data.client_id,
      clientName: data.clients?.name,
      siteId: data.site_id,
      siteName: data.sites?.name,
      date: data.report_date,
      workDone: data.work_done,
      issues: data.issues,
      createdAt: data.created_at
    };
  },

  async getReports(engineerId: string): Promise<DailyReport[]> {
    const { data, error } = await supabase
      .from('daily_reports')
      .select(`
        *,
        clients (name),
        sites (name),
        profiles:engineer_id (full_name)
      `)
      .eq('engineer_id', engineerId)
      .order('report_date', { ascending: false });

    if (error) {
      console.error('Error fetching reports:', error);
      return [];
    }

    return (data || []).map(item => ({
      id: item.id,
      engineerId: item.engineer_id,
      engineerName: item.profiles?.full_name,
      clientId: item.client_id,
      clientName: item.clients?.name,
      siteId: item.site_id,
      siteName: item.sites?.name,
      date: item.report_date,
      workDone: item.work_done,
      issues: item.issues,
      createdAt: item.created_at
    }));
  },

  async getAllReports(clientId?: string): Promise<DailyReport[]> {
    let query = supabase
      .from('daily_reports')
      .select(`
        *,
        clients (name),
        sites (name),
        profiles:engineer_id (full_name)
      `);

    if (clientId) {
      query = query.eq('client_id', clientId);
    }

    const { data, error } = await query.order('report_date', { ascending: false });

    if (error) {
      console.error('Error fetching all reports:', error);
      return [];
    }

    return (data || []).map(item => ({
      id: item.id,
      engineerId: item.engineer_id,
      engineerName: item.profiles?.full_name,
      clientId: item.client_id,
      clientName: item.clients?.name,
      siteId: item.site_id,
      siteName: item.sites?.name,
      date: item.report_date,
      workDone: item.work_done,
      issues: item.issues,
      createdAt: item.created_at
    }));
  }
};
