import { supabase } from '../lib/supabase';
import type { LeaveRequest } from '../types';

export const leaveService = {
  async createLeaveRequest(
    engineerId: string,
    startDate: string,
    endDate: string,
    reason: string
  ): Promise<LeaveRequest> {
    const { data, error } = await supabase
      .from('leave_requests')
      .insert({
        engineer_id: engineerId,
        start_date: startDate,
        end_date: endDate,
        reason,
        status: 'pending'
      })
      .select(`
        *,
        engineer:engineer_id (full_name),
        backup_engineer:backup_engineer_id (full_name),
        approver:approved_by (full_name)
      `)
      .single();

    if (error) {
      throw new Error(error.message);
    }

    return {
      id: data.id,
      engineerId: data.engineer_id,
      engineerName: data.engineer?.full_name,
      startDate: data.start_date,
      endDate: data.end_date,
      reason: data.reason,
      status: data.status,
      backupEngineerId: data.backup_engineer_id,
      backupEngineerName: data.backup_engineer?.full_name,
      approvedBy: data.approved_by,
      approvedByName: data.approver?.full_name,
      approvedAt: data.approved_at,
      createdAt: data.created_at
    };
  },

  async getMyLeaveRequests(engineerId: string): Promise<LeaveRequest[]> {
    const { data, error } = await supabase
      .from('leave_requests')
      .select(`
        *,
        engineer:engineer_id (full_name),
        backup_engineer:backup_engineer_id (full_name),
        approver:approved_by (full_name)
      `)
      .eq('engineer_id', engineerId)
      .order('created_at', { ascending: false });

    if (error) {
      console.error('Error fetching leave requests:', error);
      return [];
    }

    return (data || []).map(item => ({
      id: item.id,
      engineerId: item.engineer_id,
      engineerName: item.engineer?.full_name,
      startDate: item.start_date,
      endDate: item.end_date,
      reason: item.reason,
      status: item.status,
      backupEngineerId: item.backup_engineer_id,
      backupEngineerName: item.backup_engineer?.full_name,
      approvedBy: item.approved_by,
      approvedByName: item.approver?.full_name,
      approvedAt: item.approved_at,
      createdAt: item.created_at
    }));
  },

  async getAllLeaveRequests(): Promise<LeaveRequest[]> {
    const { data, error } = await supabase
      .from('leave_requests')
      .select(`
        *,
        engineer:engineer_id (full_name),
        backup_engineer:backup_engineer_id (full_name),
        approver:approved_by (full_name)
      `)
      .order('created_at', { ascending: false });

    if (error) {
      console.error('Error fetching all leave requests:', error);
      return [];
    }

    return (data || []).map(item => ({
      id: item.id,
      engineerId: item.engineer_id,
      engineerName: item.engineer?.full_name,
      startDate: item.start_date,
      endDate: item.end_date,
      reason: item.reason,
      status: item.status,
      backupEngineerId: item.backup_engineer_id,
      backupEngineerName: item.backup_engineer?.full_name,
      approvedBy: item.approved_by,
      approvedByName: item.approver?.full_name,
      approvedAt: item.approved_at,
      createdAt: item.created_at
    }));
  },

  async approveLeave(
    leaveId: string,
    approvedBy: string,
    backupEngineerId?: string
  ): Promise<LeaveRequest | null> {
    const updateData: any = {
      status: 'approved',
      approved_by: approvedBy,
      approved_at: new Date().toISOString()
    };

    if (backupEngineerId) {
      updateData.backup_engineer_id = backupEngineerId;
    }

    const { data, error } = await supabase
      .from('leave_requests')
      .update(updateData)
      .eq('id', leaveId)
      .select(`
        *,
        engineer:engineer_id (full_name),
        backup_engineer:backup_engineer_id (full_name),
        approver:approved_by (full_name)
      `)
      .maybeSingle();

    if (error) {
      console.error('Error approving leave:', error);
      return null;
    }

    if (!data) return null;

    return {
      id: data.id,
      engineerId: data.engineer_id,
      engineerName: data.engineer?.full_name,
      startDate: data.start_date,
      endDate: data.end_date,
      reason: data.reason,
      status: data.status,
      backupEngineerId: data.backup_engineer_id,
      backupEngineerName: data.backup_engineer?.full_name,
      approvedBy: data.approved_by,
      approvedByName: data.approver?.full_name,
      approvedAt: data.approved_at,
      createdAt: data.created_at
    };
  },

  async rejectLeave(leaveId: string, rejectedBy: string): Promise<LeaveRequest | null> {
    const { data, error } = await supabase
      .from('leave_requests')
      .update({
        status: 'rejected',
        approved_by: rejectedBy,
        approved_at: new Date().toISOString()
      })
      .eq('id', leaveId)
      .select(`
        *,
        engineer:engineer_id (full_name),
        backup_engineer:backup_engineer_id (full_name),
        approver:approved_by (full_name)
      `)
      .maybeSingle();

    if (error) {
      console.error('Error rejecting leave:', error);
      return null;
    }

    if (!data) return null;

    return {
      id: data.id,
      engineerId: data.engineer_id,
      engineerName: data.engineer?.full_name,
      startDate: data.start_date,
      endDate: data.end_date,
      reason: data.reason,
      status: data.status,
      backupEngineerId: data.backup_engineer_id,
      backupEngineerName: data.backup_engineer?.full_name,
      approvedBy: data.approved_by,
      approvedByName: data.approver?.full_name,
      approvedAt: data.approved_at,
      createdAt: data.created_at
    };
  }
};
