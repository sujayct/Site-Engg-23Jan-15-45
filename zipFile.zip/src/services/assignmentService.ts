import { supabase } from '../lib/supabase';
import type { Assignment, Client, Site } from '../types';

export const assignmentService = {
  async getMyAssignments(engineerId: string): Promise<Assignment[]> {
    const { data, error } = await supabase
      .from('engineer_assignments')
      .select(`
        *,
        clients (id, name, contact_person),
        sites (id, name, location),
        profiles:engineer_id (full_name)
      `)
      .eq('engineer_id', engineerId)
      .eq('is_active', true)
      .order('assigned_date', { ascending: false });

    if (error) {
      console.error('Error fetching assignments:', error);
      return [];
    }

    return (data || []).map(item => ({
      id: item.id,
      engineerId: item.engineer_id,
      engineerName: item.profiles?.full_name,
      clientId: item.client_id,
      clientName: item.clients?.name,
      siteId: item.site_id,
      siteName: item.sites?.name,
      assignedDate: item.assigned_date,
      status: item.is_active ? 'active' : 'inactive',
      createdAt: item.created_at
    }));
  },

  async getAllAssignments(): Promise<Assignment[]> {
    const { data, error } = await supabase
      .from('engineer_assignments')
      .select(`
        *,
        clients (id, name, contact_person),
        sites (id, name, location),
        profiles:engineer_id (full_name, designation)
      `)
      .eq('is_active', true)
      .order('assigned_date', { ascending: false });

    if (error) {
      console.error('Error fetching all assignments:', error);
      return [];
    }

    return (data || []).map(item => ({
      id: item.id,
      engineerId: item.engineer_id,
      engineerName: item.profiles?.full_name,
      engineerDesignation: item.profiles?.designation,
      clientId: item.client_id,
      clientName: item.clients?.name,
      siteId: item.site_id,
      siteName: item.sites?.name,
      assignedDate: item.assigned_date,
      status: item.is_active ? 'active' : 'inactive',
      createdAt: item.created_at
    }));
  },

  async getAssignmentsByClient(clientId: string): Promise<Assignment[]> {
    const { data, error } = await supabase
      .from('engineer_assignments')
      .select(`
        *,
        clients (id, name, contact_person),
        sites (id, name, location),
        profiles:engineer_id (full_name)
      `)
      .eq('client_id', clientId)
      .eq('is_active', true)
      .order('assigned_date', { ascending: false });

    if (error) {
      console.error('Error fetching client assignments:', error);
      return [];
    }

    return (data || []).map(item => ({
      id: item.id,
      engineerId: item.engineer_id,
      engineerName: item.profiles?.full_name,
      clientId: item.client_id,
      clientName: item.clients?.name,
      siteId: item.site_id,
      siteName: item.sites?.name,
      assignedDate: item.assigned_date,
      status: item.is_active ? 'active' : 'inactive',
      createdAt: item.created_at
    }));
  },

  async getAllClients(): Promise<Client[]> {
    const { data, error } = await supabase
      .from('clients')
      .select('*')
      .order('name');

    if (error) {
      console.error('Error fetching clients:', error);
      return [];
    }

    return (data || []).map(item => ({
      id: item.id,
      name: item.name,
      contactPerson: item.contact_person,
      email: item.contact_email,
      phone: item.contact_phone,
      address: item.address,
      userId: item.user_id,
      createdAt: item.created_at
    }));
  },

  async getSitesByClient(clientId: string): Promise<Site[]> {
    const { data, error } = await supabase
      .from('sites')
      .select('*')
      .eq('client_id', clientId)
      .order('name');

    if (error) {
      console.error('Error fetching sites:', error);
      return [];
    }

    return (data || []).map(item => ({
      id: item.id,
      clientId: item.client_id,
      name: item.name,
      location: item.location,
      address: item.address,
      createdAt: item.created_at
    }));
  }
};
