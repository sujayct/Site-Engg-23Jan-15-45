import { StorageService } from '../lib/storage';
import type { CheckIn, LeaveRequest, Engineer, Client } from '../types';

export interface AttendanceRecord {
  date: string;
  engineerId: string;
  engineerName: string;
  status: 'present' | 'absent' | 'leave';
  checkInTime?: string;
  checkOutTime?: string;
  hoursWorked?: number;
  site?: string;
}

export interface EngineerSummary {
  engineerId: string;
  engineerName: string;
  totalDays: number;
  presentDays: number;
  absentDays: number;
  leaveDays: number;
  totalHours: number;
  averageHoursPerDay: number;
}

export interface ClientReport {
  clientId: string;
  clientName: string;
  totalAssignments: number;
  activeEngineers: number;
  totalCheckIns: number;
  totalReports: number;
  sitesCount: number;
}

export interface BackupUsage {
  totalBackups: number;
  storageUsedMB: number;
  avgBackupSizeMB: number;
  lastBackupDate: string;
}

export interface PayrollRecord {
  engineerId: string;
  engineerName: string;
  email: string;
  phone: string;
  workingDays: number;
  totalHours: number;
  leaveDays: number;
  overtimeHours: number;
}

const calculateHoursWorked = (checkIn: CheckIn): number => {
  if (!checkIn.checkInTime || !checkIn.checkOutTime) return 0;

  const checkInDate = new Date(checkIn.checkInTime);
  const checkOutDate = new Date(checkIn.checkOutTime);
  const hours = (checkOutDate.getTime() - checkInDate.getTime()) / (1000 * 60 * 60);

  return Math.max(0, hours);
};

export const hrReportService = {
  async getDailyAttendanceRegister(date: string): Promise<AttendanceRecord[]> {
    const engineers = await StorageService.getEngineers();
    const checkIns = await StorageService.getCheckIns();
    const leaves = await StorageService.getLeaveRequests();

    const startOfDay = new Date(date);
    startOfDay.setHours(0, 0, 0, 0);
    const endOfDay = new Date(date);
    endOfDay.setHours(23, 59, 59, 999);

    const dailyCheckIns = checkIns.filter(c => {
      const checkInDate = new Date(c.checkInTime);
      return checkInDate >= startOfDay && checkInDate <= endOfDay;
    });

    const dailyLeaves = leaves.filter(l => {
      const leaveStart = new Date(l.startDate);
      const leaveEnd = new Date(l.endDate);
      return l.status === 'approved' && startOfDay >= leaveStart && startOfDay <= leaveEnd;
    });

    const records: AttendanceRecord[] = engineers.map(engineer => {
      const checkIn = dailyCheckIns.find(c => c.engineerId === engineer.id);
      const onLeave = dailyLeaves.find(l => l.engineerId === engineer.id);

      if (checkIn) {
        return {
          date,
          engineerId: engineer.id,
          engineerName: engineer.name,
          status: 'present',
          checkInTime: checkIn.checkInTime,
          checkOutTime: checkIn.checkOutTime,
          hoursWorked: calculateHoursWorked(checkIn),
          site: checkIn.siteId
        };
      } else if (onLeave) {
        return {
          date,
          engineerId: engineer.id,
          engineerName: engineer.name,
          status: 'leave'
        };
      } else {
        return {
          date,
          engineerId: engineer.id,
          engineerName: engineer.name,
          status: 'absent'
        };
      }
    });

    return records;
  },

  async getWeeklyEngineerSummary(startDate: string, endDate: string): Promise<EngineerSummary[]> {
    const engineers = await StorageService.getEngineers();
    const checkIns = await StorageService.getCheckIns();
    const leaves = await StorageService.getLeaveRequests();

    const start = new Date(startDate);
    start.setHours(0, 0, 0, 0);
    const end = new Date(endDate);
    end.setHours(23, 59, 59, 999);

    const weekCheckIns = checkIns.filter(c => {
      const checkInDate = new Date(c.checkInTime);
      return checkInDate >= start && checkInDate <= end;
    });

    const weekLeaves = leaves.filter(l => {
      const leaveStart = new Date(l.startDate);
      const leaveEnd = new Date(l.endDate);
      return l.status === 'approved' &&
             ((leaveStart >= start && leaveStart <= end) ||
              (leaveEnd >= start && leaveEnd <= end) ||
              (leaveStart <= start && leaveEnd >= end));
    });

    const totalDays = Math.ceil((end.getTime() - start.getTime()) / (1000 * 60 * 60 * 24)) + 1;

    const summaries: EngineerSummary[] = engineers.map(engineer => {
      const engineerCheckIns = weekCheckIns.filter(c => c.engineerId === engineer.id);
      const engineerLeaves = weekLeaves.filter(l => l.engineerId === engineer.id);

      const presentDays = new Set(engineerCheckIns.map(c =>
        new Date(c.checkInTime).toDateString()
      )).size;

      const leaveDays = engineerLeaves.reduce((sum, leave) => {
        const leaveStart = new Date(Math.max(new Date(leave.startDate).getTime(), start.getTime()));
        const leaveEnd = new Date(Math.min(new Date(leave.endDate).getTime(), end.getTime()));
        return sum + Math.ceil((leaveEnd.getTime() - leaveStart.getTime()) / (1000 * 60 * 60 * 24)) + 1;
      }, 0);

      const absentDays = totalDays - presentDays - leaveDays;

      const totalHours = engineerCheckIns.reduce((sum, checkIn) =>
        sum + calculateHoursWorked(checkIn), 0
      );

      return {
        engineerId: engineer.id,
        engineerName: engineer.name,
        totalDays,
        presentDays,
        absentDays: Math.max(0, absentDays),
        leaveDays,
        totalHours: Math.round(totalHours * 100) / 100,
        averageHoursPerDay: presentDays > 0 ? Math.round((totalHours / presentDays) * 100) / 100 : 0
      };
    });

    return summaries;
  },

  async getMonthlyClientReport(month: string): Promise<ClientReport[]> {
    const clients = await StorageService.getClients();
    const assignments = await StorageService.getAssignments();
    const checkIns = await StorageService.getCheckIns();
    const reports = await StorageService.getDailyReports();
    const sites = await StorageService.getSites();

    const monthDate = new Date(month);
    const startOfMonth = new Date(monthDate.getFullYear(), monthDate.getMonth(), 1);
    const endOfMonth = new Date(monthDate.getFullYear(), monthDate.getMonth() + 1, 0, 23, 59, 59);

    const monthCheckIns = checkIns.filter(c => {
      const checkInDate = new Date(c.checkInTime);
      return checkInDate >= startOfMonth && checkInDate <= endOfMonth;
    });

    const monthReports = reports.filter(r => {
      const reportDate = new Date(r.date);
      return reportDate >= startOfMonth && reportDate <= endOfMonth;
    });

    const clientReports: ClientReport[] = clients.map(client => {
      const clientSites = sites.filter(s => s.clientId === client.id);
      const clientAssignments = assignments.filter(a => a.clientId === client.id);

      const activeEngineers = new Set(
        clientAssignments
          .filter(a => a.status === 'active')
          .map(a => a.engineerId)
      ).size;

      const clientCheckIns = monthCheckIns.filter(c =>
        clientSites.some(s => s.id === c.siteId)
      );

      const clientReports = monthReports.filter(r =>
        clientAssignments.some(a => a.engineerId === r.engineerId)
      );

      return {
        clientId: client.id,
        clientName: client.name,
        totalAssignments: clientAssignments.length,
        activeEngineers,
        totalCheckIns: clientCheckIns.length,
        totalReports: clientReports.length,
        sitesCount: clientSites.length
      };
    });

    return clientReports;
  },

  async getBackupUsage(): Promise<BackupUsage> {
    const backups = localStorage.getItem('system_backups');

    if (!backups) {
      return {
        totalBackups: 0,
        storageUsedMB: 0,
        avgBackupSizeMB: 0,
        lastBackupDate: 'Never'
      };
    }

    const backupList = JSON.parse(backups);
    const totalBackups = backupList.length;

    const totalSize = backupList.reduce((sum: number, backup: any) => {
      const sizeInBytes = new Blob([JSON.stringify(backup.data)]).size;
      return sum + sizeInBytes;
    }, 0);

    const storageUsedMB = Math.round((totalSize / (1024 * 1024)) * 100) / 100;
    const avgBackupSizeMB = totalBackups > 0
      ? Math.round((storageUsedMB / totalBackups) * 100) / 100
      : 0;

    const lastBackup = backupList.length > 0
      ? backupList[backupList.length - 1].timestamp
      : 'Never';

    return {
      totalBackups,
      storageUsedMB,
      avgBackupSizeMB,
      lastBackupDate: lastBackup
    };
  },

  async getPayrollData(month: string): Promise<PayrollRecord[]> {
    const engineers = await StorageService.getEngineers();
    const checkIns = await StorageService.getCheckIns();
    const leaves = await StorageService.getLeaveRequests();

    const monthDate = new Date(month);
    const startOfMonth = new Date(monthDate.getFullYear(), monthDate.getMonth(), 1);
    const endOfMonth = new Date(monthDate.getFullYear(), monthDate.getMonth() + 1, 0, 23, 59, 59);

    const monthCheckIns = checkIns.filter(c => {
      const checkInDate = new Date(c.checkInTime);
      return checkInDate >= startOfMonth && checkInDate <= endOfMonth;
    });

    const monthLeaves = leaves.filter(l => {
      const leaveStart = new Date(l.startDate);
      const leaveEnd = new Date(l.endDate);
      return l.status === 'approved' &&
             ((leaveStart >= startOfMonth && leaveStart <= endOfMonth) ||
              (leaveEnd >= startOfMonth && leaveEnd <= endOfMonth) ||
              (leaveStart <= startOfMonth && leaveEnd >= endOfMonth));
    });

    const payrollRecords: PayrollRecord[] = engineers.map(engineer => {
      const engineerCheckIns = monthCheckIns.filter(c => c.engineerId === engineer.id);
      const engineerLeaves = monthLeaves.filter(l => l.engineerId === engineer.id);

      const workingDays = new Set(engineerCheckIns.map(c =>
        new Date(c.checkInTime).toDateString()
      )).size;

      const totalHours = engineerCheckIns.reduce((sum, checkIn) =>
        sum + calculateHoursWorked(checkIn), 0
      );

      const leaveDays = engineerLeaves.reduce((sum, leave) => {
        const leaveStart = new Date(Math.max(new Date(leave.startDate).getTime(), startOfMonth.getTime()));
        const leaveEnd = new Date(Math.min(new Date(leave.endDate).getTime(), endOfMonth.getTime()));
        return sum + Math.ceil((leaveEnd.getTime() - leaveStart.getTime()) / (1000 * 60 * 60 * 24)) + 1;
      }, 0);

      const standardHoursPerDay = 8;
      const overtimeHours = Math.max(0, totalHours - (workingDays * standardHoursPerDay));

      return {
        engineerId: engineer.id,
        engineerName: engineer.name,
        email: engineer.email,
        phone: engineer.phone || '',
        workingDays,
        totalHours: Math.round(totalHours * 100) / 100,
        leaveDays,
        overtimeHours: Math.round(overtimeHours * 100) / 100
      };
    });

    return payrollRecords;
  },

  exportPayrollToCSV(payrollData: PayrollRecord[], month: string): string {
    const headers = [
      'Employee ID',
      'Employee Name',
      'Email',
      'Phone',
      'Working Days',
      'Total Hours',
      'Leave Days',
      'Overtime Hours'
    ];

    const rows = payrollData.map(record => [
      record.engineerId,
      record.engineerName,
      record.email,
      record.phone,
      record.workingDays.toString(),
      record.totalHours.toString(),
      record.leaveDays.toString(),
      record.overtimeHours.toString()
    ]);

    const csvContent = [
      headers.join(','),
      ...rows.map(row => row.join(','))
    ].join('\n');

    return csvContent;
  },

  downloadCSV(csvContent: string, filename: string): void {
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);

    link.setAttribute('href', url);
    link.setAttribute('download', filename);
    link.style.visibility = 'hidden';

    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }
};
