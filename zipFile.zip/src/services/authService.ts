import { supabase } from '../lib/supabase';
import type { User } from '../types';

export interface AuthResponse {
  user: User | null;
  error: string | null;
}

export interface SignUpData {
  email: string;
  password: string;
  fullName: string;
  role: 'admin' | 'engineer' | 'hr' | 'client';
  phone?: string;
}

const STORAGE_KEY = 'auth_user';

const authStateChangeCallbacks: ((user: User | null) => void)[] = [];

export const authService = {
  async signUp(data: SignUpData): Promise<AuthResponse> {
    try {
      const { data: authData, error: signUpError } = await supabase.auth.signUp({
        email: data.email,
        password: data.password,
      });

      if (signUpError) {
        return {
          user: null,
          error: signUpError.message
        };
      }

      if (!authData.user) {
        return {
          user: null,
          error: 'Sign up failed'
        };
      }

      const { error: profileError } = await supabase
        .from('profiles')
        .insert({
          id: authData.user.id,
          email: data.email,
          full_name: data.fullName,
          role: data.role,
          phone: data.phone
        });

      if (profileError) {
        return {
          user: null,
          error: profileError.message
        };
      }

      const newUser: User = {
        id: authData.user.id,
        email: data.email,
        name: data.fullName,
        role: data.role,
        phone: data.phone,
        createdAt: new Date().toISOString()
      };

      localStorage.setItem(STORAGE_KEY, JSON.stringify(newUser));
      authStateChangeCallbacks.forEach(cb => cb(newUser));

      return {
        user: newUser,
        error: null
      };
    } catch (error: any) {
      return {
        user: null,
        error: error.message || 'Sign up failed'
      };
    }
  },

  async signIn(email: string, password: string): Promise<AuthResponse> {
    try {
      const { data: authData, error: signInError } = await supabase.auth.signInWithPassword({
        email,
        password
      });

      if (signInError) {
        return {
          user: null,
          error: 'Invalid email or password'
        };
      }

      if (!authData.user) {
        return {
          user: null,
          error: 'Sign in failed'
        };
      }

      const { data: profile, error: profileError } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', authData.user.id)
        .maybeSingle();

      if (profileError || !profile) {
        console.error('Profile fetch error:', profileError);
        return {
          user: null,
          error: profileError?.message || 'User profile not found'
        };
      }

      const authenticatedUser: User = {
        id: profile.id,
        email: profile.email,
        name: profile.full_name,
        role: profile.role,
        phone: profile.phone,
        createdAt: profile.created_at
      };

      console.log('Logged in role:', authenticatedUser.role);

      localStorage.setItem(STORAGE_KEY, JSON.stringify(authenticatedUser));
      authStateChangeCallbacks.forEach(cb => cb(authenticatedUser));

      return {
        user: authenticatedUser,
        error: null
      };
    } catch (error: any) {
      return {
        user: null,
        error: error.message || 'Sign in failed'
      };
    }
  },

  async signOut(): Promise<{ error: string | null }> {
    try {
      const { error } = await supabase.auth.signOut();
      if (error) {
        return { error: error.message };
      }
      localStorage.removeItem(STORAGE_KEY);
      authStateChangeCallbacks.forEach(cb => cb(null));
      return { error: null };
    } catch (error: any) {
      return { error: error.message || 'Sign out failed' };
    }
  },

  async getCurrentUser(): Promise<User | null> {
    try {
      const userJson = localStorage.getItem(STORAGE_KEY);
      if (!userJson) return null;

      const user = JSON.parse(userJson);
      if (user.role) {
        user.role = user.role.toLowerCase();
      }
      return user;
    } catch {
      return null;
    }
  },

  getCurrentUserRole(): string | null {
    try {
      const userJson = localStorage.getItem(STORAGE_KEY);
      if (!userJson) return null;

      const user = JSON.parse(userJson);
      return user.role ? user.role.toLowerCase() : null;
    } catch {
      return null;
    }
  },

  isAdmin(): boolean {
    try {
      const userJson = localStorage.getItem(STORAGE_KEY);
      if (!userJson) return false;

      const user = JSON.parse(userJson);
      const role = user.role ? user.role.toLowerCase().trim() : '';
      return role === 'admin';
    } catch {
      return false;
    }
  },

  async resetPassword(email: string): Promise<{ error: string | null }> {
    try {
      const { error } = await supabase.auth.resetPasswordForEmail(email);
      if (error) {
        return { error: error.message };
      }
      return { error: null };
    } catch (error: any) {
      return { error: error.message || 'Password reset failed' };
    }
  },

  async updatePassword(newPassword: string): Promise<{ error: string | null }> {
    try {
      const { error } = await supabase.auth.updateUser({
        password: newPassword
      });
      if (error) {
        return { error: error.message };
      }
      return { error: null };
    } catch (error: any) {
      return { error: error.message || 'Password update failed' };
    }
  },

  async getSession() {
    const user = await this.getCurrentUser();
    return user ? { user } : null;
  },

  onAuthStateChange(callback: (user: User | null) => void) {
    authStateChangeCallbacks.push(callback);

    return {
      data: {
        subscription: {
          unsubscribe: () => {
            const index = authStateChangeCallbacks.indexOf(callback);
            if (index > -1) {
              authStateChangeCallbacks.splice(index, 1);
            }
          }
        }
      }
    };
  }
};
