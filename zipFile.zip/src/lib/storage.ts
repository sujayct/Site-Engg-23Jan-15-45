import { supabase } from './supabase';
import { authService } from '../services/authService';
import { apiClient } from './apiClient';
import type { User, Engineer, Client, Site, Assignment, CheckIn, DailyReport, LeaveRequest } from '../types';

export const StorageService = {
  login: async (email: string, password: string): Promise<User | null> => {
    const { user, error } = await authService.signIn(email, password);
    if (error) {
      console.error('Login error:', error);
      return null;
    }
    return user;
  },

  getUsers: async (): Promise<User[]> => {
    const { data, error } = await supabase
      .from('profiles')
      .select('*')
      .order('created_at', { ascending: false });

    if (error) {
      console.error('Error fetching users:', error);
      return [];
    }

    return data.map(profile => ({
      id: profile.id,
      email: profile.email,
      name: profile.full_name,
      role: profile.role,
      phone: profile.phone || undefined,
      createdAt: profile.created_at
    }));
  },

  getUserById: async (id: string): Promise<User | null> => {
    const { data, error } = await supabase
      .from('profiles')
      .select('*')
      .eq('id', id)
      .maybeSingle();

    if (error || !data) {
      console.error('Error fetching user:', error);
      return null;
    }

    return {
      id: data.id,
      email: data.email,
      name: data.full_name,
      role: data.role,
      phone: data.phone || undefined,
      createdAt: data.created_at
    };
  },

  getEngineers: async (): Promise<Engineer[]> => {
    const { data, error } = await supabase
      .from('profiles')
      .select('*')
      .eq('role', 'engineer')
      .order('created_at', { ascending: false });

    if (error) {
      console.error('Error fetching engineers:', error);
      return [];
    }

    return data.map(profile => ({
      id: profile.id,
      name: profile.full_name,
      email: profile.email,
      phone: profile.phone || undefined,
      status: 'available' as const,
      userId: profile.id,
      createdAt: profile.created_at
    }));
  },

  getEngineerById: async (id: string): Promise<Engineer | null> => {
    const { data, error } = await supabase
      .from('profiles')
      .select('*')
      .eq('id', id)
      .eq('role', 'engineer')
      .maybeSingle();

    if (error || !data) {
      console.error('Error fetching engineer:', error);
      return null;
    }

    return {
      id: data.id,
      name: data.full_name,
      email: data.email,
      phone: data.phone || undefined,
      status: 'available',
      userId: data.id,
      createdAt: data.created_at
    };
  },

  getEngineerByUserId: async (userId: string): Promise<Engineer | null> => {
    return StorageService.getEngineerById(userId);
  },

  getClients: async (): Promise<Client[]> => {
    const { data, error } = await supabase
      .from('clients')
      .select('*')
      .order('created_at', { ascending: false });

    if (error) {
      console.error('Error fetching clients:', error);
      return [];
    }

    return data.map(client => ({
      id: client.id,
      name: client.name,
      contactPerson: client.contact_person,
      email: client.contact_email,
      phone: client.contact_phone || undefined,
      company: client.name,
      userId: client.user_id || '',
      createdAt: client.created_at
    }));
  },

  getClientById: async (id: string): Promise<Client | null> => {
    const { data, error } = await supabase
      .from('clients')
      .select('*')
      .eq('id', id)
      .maybeSingle();

    if (error || !data) {
      console.error('Error fetching client:', error);
      return null;
    }

    return {
      id: data.id,
      name: data.name,
      contactPerson: data.contact_person,
      email: data.contact_email,
      phone: data.contact_phone || undefined,
      company: data.name,
      userId: data.user_id || '',
      createdAt: data.created_at
    };
  },

  getClientByUserId: async (userId: string): Promise<Client | null> => {
    const { data, error } = await supabase
      .from('clients')
      .select('*')
      .eq('user_id', userId)
      .maybeSingle();

    if (error || !data) {
      console.error('Error fetching client by user id:', error);
      return null;
    }

    return {
      id: data.id,
      name: data.name,
      contactPerson: data.contact_person,
      email: data.contact_email,
      phone: data.contact_phone || undefined,
      company: data.name,
      userId: data.user_id || '',
      createdAt: data.created_at
    };
  },

  getSites: async (): Promise<Site[]> => {
    const { data, error } = await supabase
      .from('sites')
      .select('*')
      .order('created_at', { ascending: false });

    if (error) {
      console.error('Error fetching sites:', error);
      return [];
    }

    return data.map(site => ({
      id: site.id,
      clientId: site.client_id,
      name: site.name,
      location: site.location || site.address || '',
      status: 'active',
      createdAt: site.created_at
    }));
  },

  getSiteById: async (id: string): Promise<Site | null> => {
    const { data, error } = await supabase
      .from('sites')
      .select('*')
      .eq('id', id)
      .maybeSingle();

    if (error || !data) {
      console.error('Error fetching site:', error);
      return null;
    }

    return {
      id: data.id,
      clientId: data.client_id,
      name: data.name,
      location: data.location || data.address || '',
      status: 'active',
      createdAt: data.created_at
    };
  },

  getSitesByClientId: async (clientId: string): Promise<Site[]> => {
    const { data, error } = await supabase
      .from('sites')
      .select('*')
      .eq('client_id', clientId)
      .order('created_at', { ascending: false });

    if (error) {
      console.error('Error fetching sites by client:', error);
      return [];
    }

    return data.map(site => ({
      id: site.id,
      clientId: site.client_id,
      name: site.name,
      location: site.location || site.address || '',
      status: 'active',
      createdAt: site.created_at
    }));
  },

  getAssignments: async (): Promise<Assignment[]> => {
    const { data, error } = await supabase
      .from('engineer_assignments')
      .select('*')
      .order('created_at', { ascending: false });

    if (error) {
      console.error('Error fetching assignments:', error);
      return [];
    }

    return data.map(assignment => ({
      id: assignment.id,
      engineerId: assignment.engineer_id,
      clientId: assignment.client_id,
      siteId: assignment.site_id || '',
      startDate: assignment.assigned_date,
      status: assignment.is_active ? 'active' : 'completed',
      createdAt: assignment.created_at
    }));
  },

  getAssignmentById: async (id: string): Promise<Assignment | null> => {
    const { data, error } = await supabase
      .from('engineer_assignments')
      .select('*')
      .eq('id', id)
      .maybeSingle();

    if (error || !data) {
      console.error('Error fetching assignment:', error);
      return null;
    }

    return {
      id: data.id,
      engineerId: data.engineer_id,
      clientId: data.client_id,
      siteId: data.site_id || '',
      startDate: data.assigned_date,
      status: data.is_active ? 'active' : 'completed',
      createdAt: data.created_at
    };
  },

  getAssignmentsByEngineerId: async (engineerId: string): Promise<Assignment[]> => {
    const { data, error } = await supabase
      .from('engineer_assignments')
      .select('*')
      .eq('engineer_id', engineerId)
      .order('created_at', { ascending: false });

    if (error) {
      console.error('Error fetching assignments by engineer:', error);
      return [];
    }

    return data.map(assignment => ({
      id: assignment.id,
      engineerId: assignment.engineer_id,
      clientId: assignment.client_id,
      siteId: assignment.site_id || '',
      startDate: assignment.assigned_date,
      status: assignment.is_active ? 'active' : 'completed',
      createdAt: assignment.created_at
    }));
  },

  getAssignmentsByClientId: async (clientId: string): Promise<Assignment[]> => {
    const { data, error } = await supabase
      .from('engineer_assignments')
      .select('*')
      .eq('client_id', clientId)
      .order('created_at', { ascending: false });

    if (error) {
      console.error('Error fetching assignments by client:', error);
      return [];
    }

    return data.map(assignment => ({
      id: assignment.id,
      engineerId: assignment.engineer_id,
      clientId: assignment.client_id,
      siteId: assignment.site_id || '',
      startDate: assignment.assigned_date,
      status: assignment.is_active ? 'active' : 'completed',
      createdAt: assignment.created_at
    }));
  },

  getCheckIns: async (): Promise<CheckIn[]> => {
    const { data, error } = await supabase
      .from('check_ins')
      .select('*')
      .order('created_at', { ascending: false });

    if (error) {
      console.error('Error fetching check-ins:', error);
      return [];
    }

    return data.map(checkIn => ({
      id: checkIn.id,
      engineerId: checkIn.engineer_id,
      checkInTime: checkIn.check_in_time,
      checkOutTime: checkIn.check_out_time || undefined,
      latitude: checkIn.latitude || undefined,
      longitude: checkIn.longitude || undefined,
      locationName: checkIn.location_name || undefined,
      date: checkIn.date,
      createdAt: checkIn.created_at
    }));
  },

  getCheckInsByEngineerId: async (engineerId: string): Promise<CheckIn[]> => {
    const { data, error } = await supabase
      .from('check_ins')
      .select('*')
      .eq('engineer_id', engineerId)
      .order('date', { ascending: false });

    if (error) {
      console.error('Error fetching check-ins by engineer:', error);
      return [];
    }

    return data.map(checkIn => ({
      id: checkIn.id,
      engineerId: checkIn.engineer_id,
      checkInTime: checkIn.check_in_time,
      checkOutTime: checkIn.check_out_time || undefined,
      latitude: checkIn.latitude || undefined,
      longitude: checkIn.longitude || undefined,
      locationName: checkIn.location_name || undefined,
      date: checkIn.date,
      createdAt: checkIn.created_at
    }));
  },

  getTodayCheckIn: async (engineerId: string): Promise<CheckIn | null> => {
    const today = new Date().toISOString().split('T')[0];
    const { data, error } = await supabase
      .from('check_ins')
      .select('*')
      .eq('engineer_id', engineerId)
      .eq('date', today)
      .maybeSingle();

    if (error || !data) {
      return null;
    }

    return {
      id: data.id,
      engineerId: data.engineer_id,
      checkInTime: data.check_in_time,
      checkOutTime: data.check_out_time || undefined,
      latitude: data.latitude || undefined,
      longitude: data.longitude || undefined,
      locationName: data.location_name || undefined,
      date: data.date,
      createdAt: data.created_at
    };
  },

  createCheckIn: async (checkIn: Omit<CheckIn, 'id' | 'createdAt'>): Promise<CheckIn> => {
    const { data, error } = await supabase
      .from('check_ins')
      .insert({
        engineer_id: checkIn.engineerId,
        check_in_time: checkIn.checkInTime,
        check_out_time: checkIn.checkOutTime || null,
        latitude: checkIn.latitude || null,
        longitude: checkIn.longitude || null,
        location_name: checkIn.locationName || null,
        date: checkIn.date
      })
      .select()
      .single();

    if (error) throw error;

    return {
      id: data.id,
      engineerId: data.engineer_id,
      checkInTime: data.check_in_time,
      checkOutTime: data.check_out_time || undefined,
      latitude: data.latitude || undefined,
      longitude: data.longitude || undefined,
      locationName: data.location_name || undefined,
      date: data.date,
      createdAt: data.created_at
    };
  },

  getDailyReports: async (): Promise<DailyReport[]> => {
    const { data, error } = await supabase
      .from('daily_reports')
      .select('*')
      .order('report_date', { ascending: false });

    if (error) {
      console.error('Error fetching daily reports:', error);
      return [];
    }

    return data.map(report => ({
      id: report.id,
      engineerId: report.engineer_id,
      clientId: report.client_id,
      siteId: report.site_id || undefined,
      date: report.report_date,
      workDone: report.work_done,
      issues: report.issues || undefined,
      createdAt: report.created_at
    }));
  },

  getDailyReportsByEngineerId: async (engineerId: string): Promise<DailyReport[]> => {
    const { data, error } = await supabase
      .from('daily_reports')
      .select('*')
      .eq('engineer_id', engineerId)
      .order('report_date', { ascending: false });

    if (error) {
      console.error('Error fetching reports by engineer:', error);
      return [];
    }

    return data.map(report => ({
      id: report.id,
      engineerId: report.engineer_id,
      clientId: report.client_id,
      siteId: report.site_id || undefined,
      date: report.report_date,
      workDone: report.work_done,
      issues: report.issues || undefined,
      createdAt: report.created_at
    }));
  },

  getDailyReportsByClientId: async (clientId: string): Promise<DailyReport[]> => {
    const { data, error } = await supabase
      .from('daily_reports')
      .select('*')
      .eq('client_id', clientId)
      .order('report_date', { ascending: false });

    if (error) {
      console.error('Error fetching reports by client:', error);
      return [];
    }

    return data.map(report => ({
      id: report.id,
      engineerId: report.engineer_id,
      clientId: report.client_id,
      siteId: report.site_id || undefined,
      date: report.report_date,
      workDone: report.work_done,
      issues: report.issues || undefined,
      createdAt: report.created_at
    }));
  },

  createDailyReport: async (report: Omit<DailyReport, 'id' | 'createdAt'>): Promise<DailyReport> => {
    const { data, error } = await supabase
      .from('daily_reports')
      .insert({
        engineer_id: report.engineerId,
        client_id: report.clientId,
        site_id: report.siteId || null,
        report_date: report.date,
        work_done: report.workDone,
        issues: report.issues || null
      })
      .select()
      .single();

    if (error) throw error;

    return {
      id: data.id,
      engineerId: data.engineer_id,
      clientId: data.client_id,
      siteId: data.site_id || undefined,
      date: data.report_date,
      workDone: data.work_done,
      issues: data.issues || undefined,
      createdAt: data.created_at
    };
  },

  getLeaveRequests: async (): Promise<LeaveRequest[]> => {
    const { data, error } = await supabase
      .from('leave_requests')
      .select('*')
      .order('created_at', { ascending: false });

    if (error) {
      console.error('Error fetching leave requests:', error);
      return [];
    }

    return data.map(leave => ({
      id: leave.id,
      engineerId: leave.engineer_id,
      startDate: leave.start_date,
      endDate: leave.end_date,
      reason: leave.reason,
      status: leave.status,
      backupEngineerId: leave.backup_engineer_id || undefined,
      approvedBy: leave.approved_by || undefined,
      approvedAt: leave.approved_at || undefined,
      createdAt: leave.created_at
    }));
  },

  getLeaveRequestsByEngineerId: async (engineerId: string): Promise<LeaveRequest[]> => {
    const { data, error } = await supabase
      .from('leave_requests')
      .select('*')
      .eq('engineer_id', engineerId)
      .order('created_at', { ascending: false });

    if (error) {
      console.error('Error fetching leave requests by engineer:', error);
      return [];
    }

    return data.map(leave => ({
      id: leave.id,
      engineerId: leave.engineer_id,
      startDate: leave.start_date,
      endDate: leave.end_date,
      reason: leave.reason,
      status: leave.status,
      backupEngineerId: leave.backup_engineer_id || undefined,
      approvedBy: leave.approved_by || undefined,
      approvedAt: leave.approved_at || undefined,
      createdAt: leave.created_at
    }));
  },

  createLeaveRequest: async (leave: Omit<LeaveRequest, 'id' | 'createdAt'>): Promise<LeaveRequest> => {
    const { data, error } = await supabase
      .from('leave_requests')
      .insert({
        engineer_id: leave.engineerId,
        start_date: leave.startDate,
        end_date: leave.endDate,
        reason: leave.reason,
        status: 'pending',
        backup_engineer_id: leave.backupEngineerId || null
      })
      .select()
      .single();

    if (error) throw error;

    return {
      id: data.id,
      engineerId: data.engineer_id,
      startDate: data.start_date,
      endDate: data.end_date,
      reason: data.reason,
      status: data.status,
      backupEngineerId: data.backup_engineer_id || undefined,
      approvedBy: data.approved_by || undefined,
      approvedAt: data.approved_at || undefined,
      createdAt: data.created_at
    };
  },

  updateLeaveRequest: async (id: string, updates: Partial<LeaveRequest>): Promise<LeaveRequest | null> => {
    const updateData: any = {};

    if (updates.status) updateData.status = updates.status;
    if (updates.backupEngineerId) updateData.backup_engineer_id = updates.backupEngineerId;
    if (updates.approvedBy) updateData.approved_by = updates.approvedBy;
    if (updates.approvedAt) updateData.approved_at = updates.approvedAt;

    const { data, error } = await supabase
      .from('leave_requests')
      .update(updateData)
      .eq('id', id)
      .select()
      .single();

    if (error || !data) {
      console.error('Error updating leave request:', error);
      return null;
    }

    return {
      id: data.id,
      engineerId: data.engineer_id,
      startDate: data.start_date,
      endDate: data.end_date,
      reason: data.reason,
      status: data.status,
      backupEngineerId: data.backup_engineer_id || undefined,
      approvedBy: data.approved_by || undefined,
      approvedAt: data.approved_at || undefined,
      createdAt: data.created_at
    };
  },

  assignBackupEngineer: async (leaveRequestId: string, backupEngineerId: string): Promise<LeaveRequest | null> => {
    const { data, error } = await supabase
      .from('leave_requests')
      .update({ backup_engineer_id: backupEngineerId })
      .eq('id', leaveRequestId)
      .select()
      .single();

    if (error || !data) {
      console.error('Error assigning backup engineer:', error);
      return null;
    }

    return {
      id: data.id,
      engineerId: data.engineer_id,
      startDate: data.start_date,
      endDate: data.end_date,
      reason: data.reason,
      status: data.status,
      backupEngineerId: data.backup_engineer_id || undefined,
      approvedBy: data.approved_by || undefined,
      approvedAt: data.approved_at || undefined,
      createdAt: data.created_at
    };
  },

  getStats: async () => {
    return apiClient.get('/dashboard');
  },

  resetData: (): void => {
    console.warn('resetData is not supported with database storage');
  },

  exportData: (): string => {
    console.warn('exportData is not supported with database storage');
    return '{}';
  },

  importData: (jsonData: string): boolean => {
    console.warn('importData is not supported with database storage');
    return false;
  }
};
