import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

let supabase: any = null;

if (!supabaseUrl || !supabaseAnonKey || supabaseUrl.includes('your-') || supabaseAnonKey === 'your-anon-key') {
  console.error('⚠️ Supabase environment variables are not configured');
  console.error('Please set VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY in .env.local');
  
  // Create a dummy client to prevent crashes
  supabase = createClient('https://dummy.supabase.co', 'dummy-key', {
    auth: {
      autoRefreshToken: false,
      persistSession: false,
      detectSessionInUrl: false
    }
  });
} else {
  supabase = createClient(supabaseUrl, supabaseAnonKey, {
    auth: {
      autoRefreshToken: true,
      persistSession: true,
      detectSessionInUrl: true
    }
  });
}

export { supabase };

export type Database = {
  public: {
    Tables: {
      profiles: {
        Row: {
          id: string;
          email: string;
          full_name: string;
          role: 'admin' | 'engineer' | 'hr' | 'client';
          phone: string | null;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id: string;
          email: string;
          full_name: string;
          role: 'admin' | 'engineer' | 'hr' | 'client';
          phone?: string | null;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          email?: string;
          full_name?: string;
          role?: 'admin' | 'engineer' | 'hr' | 'client';
          phone?: string | null;
          created_at?: string;
          updated_at?: string;
        };
      };
      clients: {
        Row: {
          id: string;
          name: string;
          contact_person: string;
          contact_email: string;
          contact_phone: string | null;
          address: string | null;
          user_id: string | null;
          created_at: string;
          updated_at: string;
        };
      };
      sites: {
        Row: {
          id: string;
          client_id: string;
          name: string;
          location: string | null;
          address: string | null;
          created_at: string;
        };
      };
      engineer_assignments: {
        Row: {
          id: string;
          engineer_id: string;
          client_id: string;
          site_id: string | null;
          assigned_date: string;
          is_active: boolean;
          created_at: string;
        };
      };
      check_ins: {
        Row: {
          id: string;
          engineer_id: string;
          check_in_time: string;
          check_out_time: string | null;
          latitude: number | null;
          longitude: number | null;
          location_name: string | null;
          date: string;
          created_at: string;
        };
      };
      daily_reports: {
        Row: {
          id: string;
          engineer_id: string;
          client_id: string;
          site_id: string | null;
          report_date: string;
          work_done: string;
          issues: string | null;
          created_at: string;
          updated_at: string;
        };
      };
      leave_requests: {
        Row: {
          id: string;
          engineer_id: string;
          start_date: string;
          end_date: string;
          reason: string;
          status: 'pending' | 'approved' | 'rejected';
          backup_engineer_id: string | null;
          approved_by: string | null;
          approved_at: string | null;
          created_at: string;
        };
      };
    };
  };
};
