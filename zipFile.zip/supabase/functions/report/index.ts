import { createClient } from 'npm:@supabase/supabase-js@2.88.0';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Client-Info, Apikey',
};

Deno.serve(async (req: Request) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const authHeader = req.headers.get('Authorization');
    if (!authHeader) {
      return new Response(
        JSON.stringify({ error: 'Missing authorization header' }),
        {
          status: 401,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        }
      );
    }

    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_ANON_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseKey, {
      global: {
        headers: { Authorization: authHeader },
      },
    });

    const { data: { user }, error: userError } = await supabase.auth.getUser();
    if (userError || !user) {
      return new Response(
        JSON.stringify({ error: 'Unauthorized' }),
        {
          status: 401,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        }
      );
    }

    if (req.method === 'POST') {
      const { clientId, workDone, issues, siteId, hoursWorked } = await req.json();

      if (!clientId || !workDone) {
        return new Response(
          JSON.stringify({ error: 'clientId and workDone are required' }),
          {
            status: 400,
            headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          }
        );
      }

      const today = new Date().toISOString().split('T')[0];

      const { data: report, error: reportError } = await supabase
        .from('daily_reports')
        .insert({
          engineer_id: user.id,
          client_id: clientId,
          site_id: siteId || null,
          report_date: today,
          work_done: workDone,
          issues: issues || null,
        })
        .select()
        .single();

      if (reportError) {
        return new Response(
          JSON.stringify({ error: reportError.message }),
          {
            status: 500,
            headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          }
        );
      }

      (async () => {
        try {
          const { data: profile } = await supabase
            .from('profiles')
            .select('full_name')
            .eq('id', user.id)
            .maybeSingle();

          const { data: client } = await supabase
            .from('profiles')
            .select('full_name, email')
            .eq('id', clientId)
            .maybeSingle();

          if (profile && client && client.email) {
            await fetch(`${supabaseUrl}/functions/v1/send-email`, {
              method: 'POST',
              headers: {
                'Authorization': authHeader,
                'Content-Type': 'application/json',
              },
              body: JSON.stringify({
                to: [client.email],
                subject: `Daily Report: ${profile.full_name} - ${today}`,
                html: `
                  <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
                    <div style="background: #059669; color: white; padding: 20px; border-radius: 8px 8px 0 0;">
                      <h2 style="margin: 0;">Daily Work Report</h2>
                    </div>
                    <div style="background: #f9fafb; padding: 30px; border: 1px solid #e5e7eb;">
                      <p>Dear ${client.full_name} Team,</p>
                      <p>Please find the daily work report from <strong>${profile.full_name}</strong>.</p>
                      <div style="margin: 15px 0; padding: 10px; background: white; border-radius: 4px;">
                        <strong>Date:</strong> ${today}
                      </div>
                      ${hoursWorked ? `<div style="margin: 15px 0; padding: 10px; background: white; border-radius: 4px;">
                        <strong>Hours Worked:</strong> ${hoursWorked} hours
                      </div>` : ''}
                      <div style="margin: 15px 0; padding: 15px; background: white; border-radius: 4px;">
                        <strong style="display: block; margin-bottom: 5px;">Work Description:</strong>
                        <div style="white-space: pre-wrap;">${workDone}</div>
                      </div>
                      ${issues ? `<div style="margin: 15px 0; padding: 15px; background: white; border-radius: 4px;">
                        <strong style="display: block; margin-bottom: 5px;">Issues/Challenges:</strong>
                        <div style="white-space: pre-wrap;">${issues}</div>
                      </div>` : ''}
                      <p style="margin-top: 20px;">For any questions or concerns, please contact the engineer directly.</p>
                    </div>
                  </div>
                `,
              }),
            });
          }
        } catch (error) {
          console.error('Error sending report notification:', error);
        }
      })();

      return new Response(
        JSON.stringify({
          id: report.id,
          engineerId: report.engineer_id,
          clientId: report.client_id,
          siteId: report.site_id,
          date: report.report_date,
          workDone: report.work_done,
          issues: report.issues,
          hoursWorked,
          createdAt: report.created_at,
        }),
        {
          status: 201,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        }
      );
    }

    return new Response(
      JSON.stringify({ error: 'Method not allowed' }),
      {
        status: 405,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  } catch (error: any) {
    return new Response(
      JSON.stringify({ error: error.message || 'Internal server error' }),
      {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  }
});
