import { createClient } from 'npm:@supabase/supabase-js@2.88.0';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Client-Info, Apikey',
};

Deno.serve(async (req: Request) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const authHeader = req.headers.get('Authorization');
    if (!authHeader) {
      return new Response(
        JSON.stringify({ error: 'Missing authorization header' }),
        {
          status: 401,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        }
      );
    }

    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_ANON_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseKey, {
      global: {
        headers: { Authorization: authHeader },
      },
    });

    const { data: { user }, error: userError } = await supabase.auth.getUser();
    if (userError || !user) {
      return new Response(
        JSON.stringify({ error: 'Unauthorized' }),
        {
          status: 401,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        }
      );
    }

    if (req.method === 'GET') {
      const today = new Date().toISOString().split('T')[0];

      const [engineers, clients, sites, assignments, checkIns, reports, leaves] = await Promise.all([
        supabase.from('profiles').select('*').eq('role', 'engineer'),
        supabase.from('clients').select('*'),
        supabase.from('sites').select('*'),
        supabase.from('engineer_assignments').select('*'),
        supabase.from('check_ins').select('*'),
        supabase.from('daily_reports').select('*'),
        supabase.from('leave_requests').select('*'),
      ]);

      const stats = {
        totalEngineers: engineers.data?.length || 0,
        totalClients: clients.data?.length || 0,
        totalSites: sites.data?.length || 0,
        activeAssignments: assignments.data?.filter((a: any) => a.is_active).length || 0,
        todayCheckIns: checkIns.data?.filter((c: any) => c.date === today).length || 0,
        todayReports: reports.data?.filter((r: any) => r.report_date === today).length || 0,
        pendingLeaves: leaves.data?.filter((l: any) => l.status === 'pending').length || 0,
      };

      return new Response(
        JSON.stringify(stats),
        {
          status: 200,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        }
      );
    }

    return new Response(
      JSON.stringify({ error: 'Method not allowed' }),
      {
        status: 405,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  } catch (error: any) {
    return new Response(
      JSON.stringify({ error: error.message || 'Internal server error' }),
      {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  }
});
