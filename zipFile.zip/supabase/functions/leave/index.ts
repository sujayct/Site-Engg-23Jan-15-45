import { createClient } from 'npm:@supabase/supabase-js@2.88.0';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Client-Info, Apikey',
};

Deno.serve(async (req: Request) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const authHeader = req.headers.get('Authorization');
    if (!authHeader) {
      return new Response(
        JSON.stringify({ error: 'Missing authorization header' }),
        {
          status: 401,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        }
      );
    }

    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_ANON_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseKey, {
      global: {
        headers: { Authorization: authHeader },
      },
    });

    const { data: { user }, error: userError } = await supabase.auth.getUser();
    if (userError || !user) {
      return new Response(
        JSON.stringify({ error: 'Unauthorized' }),
        {
          status: 401,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        }
      );
    }

    if (req.method === 'POST') {
      const { startDate, endDate, reason } = await req.json();

      if (!startDate || !endDate || !reason) {
        return new Response(
          JSON.stringify({ error: 'startDate, endDate, and reason are required' }),
          {
            status: 400,
            headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          }
        );
      }

      const { data: leave, error: leaveError } = await supabase
        .from('leave_requests')
        .insert({
          engineer_id: user.id,
          start_date: startDate,
          end_date: endDate,
          reason,
          status: 'pending',
        })
        .select()
        .single();

      if (leaveError) {
        return new Response(
          JSON.stringify({ error: leaveError.message }),
          {
            status: 500,
            headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          }
        );
      }

      (async () => {
        try {
          const { data: profile } = await supabase
            .from('profiles')
            .select('full_name')
            .eq('id', user.id)
            .maybeSingle();

          const { data: assignment } = await supabase
            .from('assignments')
            .select('client_id')
            .eq('engineer_id', user.id)
            .eq('status', 'active')
            .maybeSingle();

          if (assignment && profile) {
            const { data: client } = await supabase
              .from('profiles')
              .select('full_name, email')
              .eq('id', assignment.client_id)
              .maybeSingle();

            if (client && client.email) {
              await fetch(`${supabaseUrl}/functions/v1/send-email`, {
                method: 'POST',
                headers: {
                  'Authorization': authHeader,
                  'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                  to: [client.email],
                  subject: `Leave Request: ${profile.full_name} - ${startDate} to ${endDate}`,
                  html: `
                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
                      <div style="background: #dc2626; color: white; padding: 20px; border-radius: 8px 8px 0 0;">
                        <h2 style="margin: 0;">Leave Request Notification</h2>
                      </div>
                      <div style="background: #f9fafb; padding: 30px; border: 1px solid #e5e7eb;">
                        <p>Dear ${client.full_name} Team,</p>
                        <p>This is to inform you about a leave request from <strong>${profile.full_name}</strong>.</p>
                        <div style="margin: 15px 0; padding: 10px; background: white; border-radius: 4px;">
                          <strong>Leave Type:</strong> Leave Request
                        </div>
                        <div style="margin: 15px 0; padding: 10px; background: white; border-radius: 4px;">
                          <strong>Start Date:</strong> ${startDate}
                        </div>
                        <div style="margin: 15px 0; padding: 10px; background: white; border-radius: 4px;">
                          <strong>End Date:</strong> ${endDate}
                        </div>
                        <div style="margin: 15px 0; padding: 10px; background: white; border-radius: 4px;">
                          <strong>Reason:</strong> ${reason}
                        </div>
                        <div style="margin: 15px 0; padding: 10px; background: white; border-radius: 4px;">
                          <strong>Status:</strong> <span style="display: inline-block; padding: 5px 15px; border-radius: 20px; font-weight: bold; background: #fef3c7; color: #92400e;">Pending</span>
                        </div>
                        <p style="margin-top: 20px;">Please plan accordingly for this period.</p>
                      </div>
                    </div>
                  `,
                }),
              });
            }
          }
        } catch (error) {
          console.error('Error sending leave notification:', error);
        }
      })();

      return new Response(
        JSON.stringify({
          id: leave.id,
          engineerId: leave.engineer_id,
          startDate: leave.start_date,
          endDate: leave.end_date,
          reason: leave.reason,
          status: leave.status,
          backupEngineerId: leave.backup_engineer_id,
          approvedBy: leave.approved_by,
          approvedAt: leave.approved_at,
          createdAt: leave.created_at,
        }),
        {
          status: 201,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        }
      );
    }

    if (req.method === 'GET') {
      const url = new URL(req.url);
      const engineerId = url.searchParams.get('engineerId');
      const all = url.searchParams.get('all');

      let query = supabase.from('leave_requests').select('*');

      if (all !== 'true' && !engineerId) {
        query = query.eq('engineer_id', user.id);
      } else if (engineerId) {
        query = query.eq('engineer_id', engineerId);
      }

      const { data: leaves, error: leavesError } = await query.order('created_at', { ascending: false });

      if (leavesError) {
        return new Response(
          JSON.stringify({ error: leavesError.message }),
          {
            status: 500,
            headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          }
        );
      }

      const mappedLeaves = leaves.map(leave => ({
        id: leave.id,
        engineerId: leave.engineer_id,
        startDate: leave.start_date,
        endDate: leave.end_date,
        reason: leave.reason,
        status: leave.status,
        backupEngineerId: leave.backup_engineer_id,
        approvedBy: leave.approved_by,
        approvedAt: leave.approved_at,
        createdAt: leave.created_at,
      }));

      return new Response(
        JSON.stringify(mappedLeaves),
        {
          status: 200,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        }
      );
    }

    if (req.method === 'PUT') {
      const url = new URL(req.url);
      const leaveId = url.searchParams.get('id');
      const { status, backupEngineerId } = await req.json();

      if (!leaveId) {
        return new Response(
          JSON.stringify({ error: 'Leave ID is required' }),
          {
            status: 400,
            headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          }
        );
      }

      const updateData: any = {};
      if (status) {
        updateData.status = status;
        updateData.approved_by = user.id;
        updateData.approved_at = new Date().toISOString();
      }
      if (backupEngineerId) {
        updateData.backup_engineer_id = backupEngineerId;
      }

      const { data: leave, error: leaveError } = await supabase
        .from('leave_requests')
        .update(updateData)
        .eq('id', leaveId)
        .select()
        .single();

      if (leaveError) {
        return new Response(
          JSON.stringify({ error: leaveError.message }),
          {
            status: 500,
            headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          }
        );
      }

      return new Response(
        JSON.stringify({
          id: leave.id,
          engineerId: leave.engineer_id,
          startDate: leave.start_date,
          endDate: leave.end_date,
          reason: leave.reason,
          status: leave.status,
          backupEngineerId: leave.backup_engineer_id,
          approvedBy: leave.approved_by,
          approvedAt: leave.approved_at,
          createdAt: leave.created_at,
        }),
        {
          status: 200,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        }
      );
    }

    return new Response(
      JSON.stringify({ error: 'Method not allowed' }),
      {
        status: 405,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  } catch (error: any) {
    return new Response(
      JSON.stringify({ error: error.message || 'Internal server error' }),
      {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  }
});
