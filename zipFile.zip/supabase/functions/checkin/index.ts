import { createClient } from 'npm:@supabase/supabase-js@2.88.0';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Client-Info, Apikey',
};

Deno.serve(async (req: Request) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const authHeader = req.headers.get('Authorization');
    if (!authHeader) {
      return new Response(
        JSON.stringify({ error: 'Missing authorization header' }),
        {
          status: 401,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        }
      );
    }

    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_ANON_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseKey, {
      global: {
        headers: { Authorization: authHeader },
      },
    });

    const { data: { user }, error: userError } = await supabase.auth.getUser();
    if (userError || !user) {
      return new Response(
        JSON.stringify({ error: 'Unauthorized' }),
        {
          status: 401,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        }
      );
    }

    if (req.method === 'POST') {
      const { latitude, longitude, locationName, siteId } = await req.json();

      const today = new Date().toISOString().split('T')[0];
      const now = new Date().toISOString();

      const { data: existingCheckIn } = await supabase
        .from('check_ins')
        .select('*')
        .eq('engineer_id', user.id)
        .eq('date', today)
        .maybeSingle();

      if (existingCheckIn) {
        return new Response(
          JSON.stringify({ error: 'Already checked in today' }),
          {
            status: 400,
            headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          }
        );
      }

      const { data: checkIn, error: checkInError } = await supabase
        .from('check_ins')
        .insert({
          engineer_id: user.id,
          check_in_time: now,
          latitude: latitude || null,
          longitude: longitude || null,
          location_name: locationName || null,
          site_id: siteId || null,
          date: today,
        })
        .select()
        .single();

      if (checkInError) {
        return new Response(
          JSON.stringify({ error: checkInError.message }),
          {
            status: 500,
            headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          }
        );
      }

      (async () => {
        try {
          const { data: profile } = await supabase
            .from('profiles')
            .select('full_name')
            .eq('id', user.id)
            .maybeSingle();

          const { data: assignment } = await supabase
            .from('assignments')
            .select('client_id')
            .eq('engineer_id', user.id)
            .eq('status', 'active')
            .maybeSingle();

          if (assignment && profile) {
            const { data: client } = await supabase
              .from('profiles')
              .select('full_name, email')
              .eq('id', assignment.client_id)
              .maybeSingle();

            if (client && client.email) {
              const time = new Date(now).toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });

              await fetch(`${supabaseUrl}/functions/v1/send-email`, {
                method: 'POST',
                headers: {
                  'Authorization': authHeader,
                  'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                  to: [client.email],
                  subject: `Check-In Update: ${profile.full_name} at ${client.full_name}`,
                  html: `
                    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
                      <div style="background: #2563eb; color: white; padding: 20px; border-radius: 8px 8px 0 0;">
                        <h2 style="margin: 0;">Engineer Check-In Notification</h2>
                      </div>
                      <div style="background: #f9fafb; padding: 30px; border: 1px solid #e5e7eb;">
                        <p>Dear ${client.full_name} Team,</p>
                        <p>This is to inform you that <strong>${profile.full_name}</strong> has checked in.</p>
                        <div style="margin: 15px 0; padding: 10px; background: white; border-radius: 4px;">
                          <strong>Date:</strong> ${today}
                        </div>
                        <div style="margin: 15px 0; padding: 10px; background: white; border-radius: 4px;">
                          <strong>Time:</strong> ${time}
                        </div>
                        ${locationName ? `<div style="margin: 15px 0; padding: 10px; background: white; border-radius: 4px;">
                          <strong>Location:</strong> ${locationName}
                        </div>` : ''}
                        <div style="margin: 15px 0; padding: 10px; background: white; border-radius: 4px;">
                          <strong>Status:</strong> Checked In
                        </div>
                        <p style="margin-top: 20px;">This is an automated notification from the Engineer Management System.</p>
                      </div>
                    </div>
                  `,
                }),
              });
            }
          }
        } catch (error) {
          console.error('Error sending check-in notification:', error);
        }
      })();

      return new Response(
        JSON.stringify({
          id: checkIn.id,
          engineerId: checkIn.engineer_id,
          checkInTime: checkIn.check_in_time,
          checkOutTime: checkIn.check_out_time,
          latitude: checkIn.latitude,
          longitude: checkIn.longitude,
          locationName: checkIn.location_name,
          date: checkIn.date,
          createdAt: checkIn.created_at,
        }),
        {
          status: 201,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        }
      );
    }

    if (req.method === 'GET') {
      const url = new URL(req.url);
      const engineerId = url.searchParams.get('engineerId');

      let query = supabase.from('check_ins').select('*');

      if (engineerId) {
        query = query.eq('engineer_id', engineerId);
      } else {
        query = query.eq('engineer_id', user.id);
      }

      const { data: checkIns, error: checkInsError } = await query.order('date', { ascending: false });

      if (checkInsError) {
        return new Response(
          JSON.stringify({ error: checkInsError.message }),
          {
            status: 500,
            headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          }
        );
      }

      const mappedCheckIns = checkIns.map(checkIn => ({
        id: checkIn.id,
        engineerId: checkIn.engineer_id,
        checkInTime: checkIn.check_in_time,
        checkOutTime: checkIn.check_out_time,
        latitude: checkIn.latitude,
        longitude: checkIn.longitude,
        locationName: checkIn.location_name,
        date: checkIn.date,
        createdAt: checkIn.created_at,
      }));

      return new Response(
        JSON.stringify(mappedCheckIns),
        {
          status: 200,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        }
      );
    }

    return new Response(
      JSON.stringify({ error: 'Method not allowed' }),
      {
        status: 405,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  } catch (error: any) {
    return new Response(
      JSON.stringify({ error: error.message || 'Internal server error' }),
      {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  }
});
