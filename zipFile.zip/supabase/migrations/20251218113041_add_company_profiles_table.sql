/*
  # Create Company Profiles Table

  ## Overview
  This migration creates the company_profiles table to store company branding and configuration data.
  Only admin users can create/edit profiles. HR has read-only access.

  ## New Tables
  
  ### `company_profiles`
  Stores company branding information including:
  - `id` (uuid, primary key) - Unique identifier
  - `company_name` (text) - Official company name
  - `brand_name` (text) - Brand/display name
  - `logo_url` (text, nullable) - URL/path to company logo
  - `primary_color` (text) - Primary brand color (hex code)
  - `secondary_color` (text) - Secondary brand color (hex code)
  - `support_email` (text) - Company support email
  - `contact_number` (text) - Company contact number
  - `address` (text) - Company address
  - `created_at` (timestamptz) - Record creation timestamp
  - `updated_at` (timestamptz) - Last update timestamp
  - `updated_by` (uuid) - User who last updated the profile

  ## Security
  
  1. Enable RLS on company_profiles table
  2. Admin users can:
     - Create company profiles
     - Update company profiles
     - Read company profiles
  3. HR users can:
     - Read company profiles only
  4. Engineer and Client users:
     - No access to company profiles
  
  ## Notes
  - Only one company profile should exist (enforced at application level)
  - Default colors are professional blue scheme
  - Logo URL can reference Supabase Storage or external URL
*/

-- Create company_profiles table
CREATE TABLE IF NOT EXISTS company_profiles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_name text NOT NULL,
  brand_name text NOT NULL,
  logo_url text,
  primary_color text DEFAULT '#2563eb' NOT NULL,
  secondary_color text DEFAULT '#1e40af' NOT NULL,
  support_email text NOT NULL,
  contact_number text NOT NULL,
  address text NOT NULL,
  created_at timestamptz DEFAULT now() NOT NULL,
  updated_at timestamptz DEFAULT now() NOT NULL,
  updated_by uuid REFERENCES profiles(id)
);

-- Enable RLS
ALTER TABLE company_profiles ENABLE ROW LEVEL SECURITY;

-- Admin can read all company profiles
CREATE POLICY "Admin can read company profiles"
  ON company_profiles
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'admin'
    )
  );

-- Admin can insert company profiles
CREATE POLICY "Admin can create company profiles"
  ON company_profiles
  FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'admin'
    )
  );

-- Admin can update company profiles
CREATE POLICY "Admin can update company profiles"
  ON company_profiles
  FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'admin'
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'admin'
    )
  );

-- HR can read company profiles (read-only)
CREATE POLICY "HR can read company profiles"
  ON company_profiles
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'hr'
    )
  );

-- Create index for faster lookups
CREATE INDEX IF NOT EXISTS idx_company_profiles_updated_at ON company_profiles(updated_at DESC);

-- Insert default company profile (if none exists)
INSERT INTO company_profiles (
  company_name,
  brand_name,
  logo_url,
  primary_color,
  secondary_color,
  support_email,
  contact_number,
  address
)
SELECT
  'Your Company Name',
  'Brand Name',
  NULL,
  '#2563eb',
  '#1e40af',
  'support@company.com',
  '+1 (555) 123-4567',
  '123 Business Street, City, State 12345'
WHERE NOT EXISTS (SELECT 1 FROM company_profiles);
