/*
  # Fix RLS with Proper Security Definer Function

  ## Problem
  The subquery approach still causes recursion because when we query profiles
  within a policy, ALL policies are evaluated again, including the ones with
  subqueries.

  ## Solution
  Create a security definer function that completely bypasses RLS by:
  1. Using SECURITY DEFINER (runs with creator's privileges)
  2. Setting search_path for security
  3. Directly querying without triggering RLS checks
  
  This function will be safe because it only returns the role of the current user.

  ## Changes Made
  - Create bypass function for role checking
  - Simplify all policies to use this function
  - Ensure own profile access remains simple
*/

-- ============================================================================
-- DROP EXISTING POLICIES
-- ============================================================================

DROP POLICY IF EXISTS "Anyone can read own profile" ON public.profiles;
DROP POLICY IF EXISTS "Anyone can update own profile" ON public.profiles;
DROP POLICY IF EXISTS "Admins can read all profiles" ON public.profiles;
DROP POLICY IF EXISTS "HR can read all profiles" ON public.profiles;
DROP POLICY IF EXISTS "Admins can insert profiles" ON public.profiles;
DROP POLICY IF EXISTS "Admins can update all profiles" ON public.profiles;
DROP POLICY IF EXISTS "Admins can delete profiles" ON public.profiles;

-- ============================================================================
-- CREATE SECURITY DEFINER FUNCTION THAT BYPASSES RLS
-- ============================================================================

CREATE OR REPLACE FUNCTION public.get_my_role()
RETURNS text
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
STABLE
AS $$
DECLARE
  user_role text;
BEGIN
  -- This query runs with the function owner's privileges
  -- and bypasses RLS entirely
  SELECT role INTO user_role
  FROM public.profiles
  WHERE id = auth.uid()
  LIMIT 1;
  
  RETURN user_role;
END;
$$;

-- Grant execute permission
GRANT EXECUTE ON FUNCTION public.get_my_role() TO authenticated;

-- Add comment explaining the function
COMMENT ON FUNCTION public.get_my_role() IS 
  'Returns the role of the currently authenticated user. Uses SECURITY DEFINER to bypass RLS and prevent infinite recursion.';

-- ============================================================================
-- CREATE SIMPLE POLICIES USING THE SECURITY DEFINER FUNCTION
-- ============================================================================

-- Policy 1: Users can read their own profile (simple, no function call)
CREATE POLICY "Users can read own profile"
  ON public.profiles
  FOR SELECT
  TO authenticated
  USING (id = auth.uid());

-- Policy 2: Users can update their own profile
CREATE POLICY "Users can update own profile"
  ON public.profiles
  FOR UPDATE
  TO authenticated
  USING (id = auth.uid())
  WITH CHECK (id = auth.uid());

-- Policy 3: Admins can read all profiles (uses security definer function)
CREATE POLICY "Admins can read all profiles"
  ON public.profiles
  FOR SELECT
  TO authenticated
  USING (get_my_role() = 'admin');

-- Policy 4: HR can read all profiles (uses security definer function)
CREATE POLICY "HR can read all profiles"
  ON public.profiles
  FOR SELECT
  TO authenticated
  USING (get_my_role() = 'hr');

-- Policy 5: Admins can insert profiles
CREATE POLICY "Admins can insert profiles"
  ON public.profiles
  FOR INSERT
  TO authenticated
  WITH CHECK (get_my_role() = 'admin');

-- Policy 6: Admins can update any profile
CREATE POLICY "Admins can update all profiles"
  ON public.profiles
  FOR UPDATE
  TO authenticated
  USING (get_my_role() = 'admin')
  WITH CHECK (get_my_role() = 'admin');

-- Policy 7: Admins can delete profiles
CREATE POLICY "Admins can delete profiles"
  ON public.profiles
  FOR DELETE
  TO authenticated
  USING (get_my_role() = 'admin');

-- ============================================================================
-- UPDATE ALL OTHER TABLES
-- ============================================================================

-- CLIENTS TABLE
DROP POLICY IF EXISTS "Admin and HR can view clients" ON public.clients;
DROP POLICY IF EXISTS "Admins can manage clients" ON public.clients;

CREATE POLICY "Admin and HR can view clients"
  ON public.clients
  FOR SELECT
  TO authenticated
  USING (get_my_role() IN ('admin', 'hr'));

CREATE POLICY "Admins can manage clients"
  ON public.clients
  FOR ALL
  TO authenticated
  USING (get_my_role() = 'admin')
  WITH CHECK (get_my_role() = 'admin');

-- SITES TABLE
DROP POLICY IF EXISTS "Admin and HR can view sites" ON public.sites;
DROP POLICY IF EXISTS "Admins can manage sites" ON public.sites;

CREATE POLICY "Admin and HR can view sites"
  ON public.sites
  FOR SELECT
  TO authenticated
  USING (get_my_role() IN ('admin', 'hr'));

CREATE POLICY "Admins can manage sites"
  ON public.sites
  FOR ALL
  TO authenticated
  USING (get_my_role() = 'admin')
  WITH CHECK (get_my_role() = 'admin');

-- ENGINEER ASSIGNMENTS TABLE
DROP POLICY IF EXISTS "Admin and HR can view assignments" ON public.engineer_assignments;
DROP POLICY IF EXISTS "Admins can manage assignments" ON public.engineer_assignments;

CREATE POLICY "Admin and HR can view assignments"
  ON public.engineer_assignments
  FOR SELECT
  TO authenticated
  USING (get_my_role() IN ('admin', 'hr'));

CREATE POLICY "Admins can manage assignments"
  ON public.engineer_assignments
  FOR ALL
  TO authenticated
  USING (get_my_role() = 'admin')
  WITH CHECK (get_my_role() = 'admin');

-- CHECK-INS TABLE
DROP POLICY IF EXISTS "Admin and HR can view check-ins" ON public.check_ins;

CREATE POLICY "Admin and HR can view check-ins"
  ON public.check_ins
  FOR SELECT
  TO authenticated
  USING (get_my_role() IN ('admin', 'hr'));

-- DAILY REPORTS TABLE
DROP POLICY IF EXISTS "Admin and HR can view reports" ON public.daily_reports;

CREATE POLICY "Admin and HR can view reports"
  ON public.daily_reports
  FOR SELECT
  TO authenticated
  USING (get_my_role() IN ('admin', 'hr'));

-- LEAVE REQUESTS TABLE
DROP POLICY IF EXISTS "Admin and HR can view leave requests" ON public.leave_requests;
DROP POLICY IF EXISTS "Admin and HR can update leave requests" ON public.leave_requests;

CREATE POLICY "Admin and HR can view leave requests"
  ON public.leave_requests
  FOR SELECT
  TO authenticated
  USING (get_my_role() IN ('admin', 'hr'));

CREATE POLICY "Admin and HR can update leave requests"
  ON public.leave_requests
  FOR UPDATE
  TO authenticated
  USING (get_my_role() IN ('admin', 'hr'))
  WITH CHECK (get_my_role() IN ('admin', 'hr'));

-- EMAIL LOGS TABLE
DROP POLICY IF EXISTS "Admin and HR can view email logs" ON public.email_logs;

CREATE POLICY "Admin and HR can view email logs"
  ON public.email_logs
  FOR SELECT
  TO authenticated
  USING (get_my_role() IN ('admin', 'hr'));

-- NOTIFICATIONS TABLE
DROP POLICY IF EXISTS "Admin and HR can view notifications" ON public.notifications;

CREATE POLICY "Admin and HR can view notifications"
  ON public.notifications
  FOR SELECT
  TO authenticated
  USING (get_my_role() IN ('admin', 'hr'));

-- ============================================================================
-- COMPLETION
-- ============================================================================

DO $$
BEGIN
  RAISE NOTICE 'Security definer function created: get_my_role()';
  RAISE NOTICE 'This function bypasses RLS to prevent infinite recursion';
  RAISE NOTICE 'All policies updated to use the new function';
END $$;
