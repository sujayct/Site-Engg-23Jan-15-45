/*
  # Add Password Reset Tokens Table

  1. New Tables
    - `password_reset_tokens`
      - `id` (uuid, primary key) - Unique identifier for the reset token
      - `email` (text, not null) - Email address of the user requesting password reset
      - `token` (text, not null, unique) - Secure reset token
      - `expires_at` (timestamptz, not null) - Token expiration timestamp
      - `used` (boolean, default false) - Flag to indicate if token has been used
      - `created_at` (timestamptz, default now()) - Timestamp when token was created

  2. Security
    - Enable RLS on `password_reset_tokens` table
    - No public access policies (tokens are managed server-side only)
    - Tokens expire after 1 hour by default
    - Tokens can only be used once

  3. Indexes
    - Index on email for faster lookups
    - Index on token for faster validation
    - Index on expires_at for cleanup queries

  4. Important Notes
    - Tokens should be generated using secure random methods
    - Expired and used tokens should be cleaned up periodically
    - This table supports the forgot password flow in the mobile app
*/

CREATE TABLE IF NOT EXISTS password_reset_tokens (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text NOT NULL,
  token text NOT NULL UNIQUE,
  expires_at timestamptz NOT NULL,
  used boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE password_reset_tokens ENABLE ROW LEVEL SECURITY;

CREATE INDEX IF NOT EXISTS idx_password_reset_tokens_email 
  ON password_reset_tokens(email);

CREATE INDEX IF NOT EXISTS idx_password_reset_tokens_token 
  ON password_reset_tokens(token);

CREATE INDEX IF NOT EXISTS idx_password_reset_tokens_expires_at 
  ON password_reset_tokens(expires_at);
