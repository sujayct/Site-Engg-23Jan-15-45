/*
  # Extend Profiles Table with Personal Information

  ## Overview
  This migration adds comprehensive profile fields to allow users to manage their personal and professional information.

  ## Changes to `profiles` Table
  
  ### Personal Information
  - `profile_photo_url` (text, nullable) - URL to profile photo in storage
  - `mobile_number` (text, nullable) - Primary mobile number
  - `alternate_number` (text, nullable) - Secondary contact number
  - `personal_email` (text, nullable) - Personal email address
  
  ### Address Information
  - `address_line1` (text, nullable) - Address line 1
  - `address_line2` (text, nullable) - Address line 2
  - `city` (text, nullable) - City
  - `state` (text, nullable) - State/Province
  - `country` (text, nullable) - Country
  - `pincode` (text, nullable) - Postal/ZIP code
  
  ### Personal Details
  - `date_of_birth` (date, nullable) - Date of birth
  - `gender` (text, nullable) - Gender (optional)
  
  ### Professional Information
  - `years_of_experience` (integer, nullable) - Years of professional experience
  - `skills` (text, nullable) - Skills/Expertise (comma-separated or text)
  - `reporting_manager` (uuid, nullable) - Reference to manager's profile
  - `linkedin_url` (text, nullable) - LinkedIn profile URL
  - `portfolio_url` (text, nullable) - Portfolio/personal website URL
  
  ## Security
  - Users can update their own profile
  - Admin and HR can view all profiles
  - Email and role fields remain admin-controlled
  
  ## Notes
  - Profile photo stored in Supabase Storage
  - All new fields are nullable for backward compatibility
  - Designation field already exists from previous migration
*/

-- Add personal information fields
DO $$
BEGIN
  -- Personal Information
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'profiles' AND column_name = 'profile_photo_url'
  ) THEN
    ALTER TABLE profiles ADD COLUMN profile_photo_url text;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'profiles' AND column_name = 'mobile_number'
  ) THEN
    ALTER TABLE profiles ADD COLUMN mobile_number text;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'profiles' AND column_name = 'alternate_number'
  ) THEN
    ALTER TABLE profiles ADD COLUMN alternate_number text;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'profiles' AND column_name = 'personal_email'
  ) THEN
    ALTER TABLE profiles ADD COLUMN personal_email text;
  END IF;

  -- Address Information
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'profiles' AND column_name = 'address_line1'
  ) THEN
    ALTER TABLE profiles ADD COLUMN address_line1 text;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'profiles' AND column_name = 'address_line2'
  ) THEN
    ALTER TABLE profiles ADD COLUMN address_line2 text;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'profiles' AND column_name = 'city'
  ) THEN
    ALTER TABLE profiles ADD COLUMN city text;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'profiles' AND column_name = 'state'
  ) THEN
    ALTER TABLE profiles ADD COLUMN state text;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'profiles' AND column_name = 'country'
  ) THEN
    ALTER TABLE profiles ADD COLUMN country text;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'profiles' AND column_name = 'pincode'
  ) THEN
    ALTER TABLE profiles ADD COLUMN pincode text;
  END IF;

  -- Personal Details
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'profiles' AND column_name = 'date_of_birth'
  ) THEN
    ALTER TABLE profiles ADD COLUMN date_of_birth date;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'profiles' AND column_name = 'gender'
  ) THEN
    ALTER TABLE profiles ADD COLUMN gender text;
  END IF;

  -- Professional Information
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'profiles' AND column_name = 'years_of_experience'
  ) THEN
    ALTER TABLE profiles ADD COLUMN years_of_experience integer;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'profiles' AND column_name = 'skills'
  ) THEN
    ALTER TABLE profiles ADD COLUMN skills text;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'profiles' AND column_name = 'reporting_manager'
  ) THEN
    ALTER TABLE profiles ADD COLUMN reporting_manager uuid REFERENCES profiles(id);
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'profiles' AND column_name = 'linkedin_url'
  ) THEN
    ALTER TABLE profiles ADD COLUMN linkedin_url text;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'profiles' AND column_name = 'portfolio_url'
  ) THEN
    ALTER TABLE profiles ADD COLUMN portfolio_url text;
  END IF;
END $$;

-- Update RLS policies to allow users to update their own profiles
-- Drop existing update policy if it exists
DROP POLICY IF EXISTS "Users can update own profile" ON profiles;

-- Create policy for users to update their own profile
CREATE POLICY "Users can update own profile"
  ON profiles
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = id)
  WITH CHECK (auth.uid() = id);

-- Admin and HR can view all profiles
DROP POLICY IF EXISTS "Admin and HR can view all profiles" ON profiles;

CREATE POLICY "Admin and HR can view all profiles"
  ON profiles
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles p
      WHERE p.id = auth.uid()
      AND p.role IN ('admin', 'hr')
    )
    OR auth.uid() = id
  );

-- Create index for reporting manager lookups
CREATE INDEX IF NOT EXISTS idx_profiles_reporting_manager ON profiles(reporting_manager);
