/*
  # Create Base Tables
  
  Creates all base tables without RLS policies first to avoid circular dependencies.
  
  Tables:
  - profiles: User information
  - clients: Client companies
  - sites: Client locations
  - engineer_assignments: Engineer-to-site mappings
  - check_ins: Daily check-in records
  - daily_reports: Work reports
  - leave_requests: Leave management
  - notifications: User notifications
  - email_logs: Email tracking
*/

-- Profiles table
CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email text UNIQUE NOT NULL,
  full_name text NOT NULL,
  role text NOT NULL CHECK (role IN ('admin', 'engineer', 'hr', 'client')),
  phone text,
  designation text,
  photo_url text,
  mobile_number text,
  alternate_number text,
  personal_email text,
  address_line1 text,
  address_line2 text,
  city text,
  state text,
  country text,
  pincode text,
  date_of_birth date,
  gender text,
  years_of_experience integer,
  skills text,
  linkedin_url text,
  portfolio_url text,
  reporting_manager_id uuid,
  reporting_manager uuid,
  profile_photo_url text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Add foreign keys for profiles after table creation
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.table_constraints 
    WHERE constraint_name = 'profiles_reporting_manager_id_fkey'
  ) THEN
    ALTER TABLE profiles ADD CONSTRAINT profiles_reporting_manager_id_fkey 
      FOREIGN KEY (reporting_manager_id) REFERENCES profiles(id);
  END IF;
  
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.table_constraints 
    WHERE constraint_name = 'profiles_reporting_manager_fkey'
  ) THEN
    ALTER TABLE profiles ADD CONSTRAINT profiles_reporting_manager_fkey 
      FOREIGN KEY (reporting_manager) REFERENCES profiles(id);
  END IF;
END $$;

-- Clients table
CREATE TABLE IF NOT EXISTS clients (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  contact_person text NOT NULL,
  contact_email text NOT NULL,
  contact_phone text,
  address text,
  user_id uuid REFERENCES profiles(id),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Sites table
CREATE TABLE IF NOT EXISTS sites (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  client_id uuid NOT NULL REFERENCES clients(id) ON DELETE CASCADE,
  name text NOT NULL,
  location text,
  address text,
  created_at timestamptz DEFAULT now()
);

-- Engineer assignments table
CREATE TABLE IF NOT EXISTS engineer_assignments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  engineer_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  client_id uuid NOT NULL REFERENCES clients(id) ON DELETE CASCADE,
  site_id uuid REFERENCES sites(id) ON DELETE SET NULL,
  assigned_date date DEFAULT CURRENT_DATE,
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now()
);

-- Check-ins table
CREATE TABLE IF NOT EXISTS check_ins (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  engineer_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  check_in_time timestamptz NOT NULL,
  check_out_time timestamptz,
  latitude numeric,
  longitude numeric,
  location_name text,
  date date NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Daily reports table
CREATE TABLE IF NOT EXISTS daily_reports (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  engineer_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  client_id uuid NOT NULL REFERENCES clients(id) ON DELETE CASCADE,
  site_id uuid REFERENCES sites(id) ON DELETE SET NULL,
  report_date date NOT NULL,
  work_done text NOT NULL,
  issues text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Leave requests table
CREATE TABLE IF NOT EXISTS leave_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  engineer_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  start_date date NOT NULL,
  end_date date NOT NULL,
  reason text NOT NULL,
  status text DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected')),
  backup_engineer_id uuid REFERENCES profiles(id),
  approved_by uuid REFERENCES profiles(id),
  approved_at timestamptz,
  created_at timestamptz DEFAULT now()
);

-- Notifications table
CREATE TABLE IF NOT EXISTS notifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  type text NOT NULL CHECK (type IN ('info', 'warning', 'success', 'error')),
  message text NOT NULL,
  is_read boolean DEFAULT false,
  created_at timestamptz DEFAULT now(),
  read_at timestamptz
);

-- Email logs table
CREATE TABLE IF NOT EXISTS email_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  recipient_email text NOT NULL,
  subject text NOT NULL,
  body text NOT NULL,
  type text NOT NULL,
  sent_at timestamptz DEFAULT now(),
  status text DEFAULT 'sent'
);

-- Company profiles table
CREATE TABLE IF NOT EXISTS company_profiles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_name text NOT NULL,
  brand_name text NOT NULL,
  logo_url text,
  primary_color text DEFAULT '#2563eb',
  secondary_color text DEFAULT '#1e40af',
  support_email text NOT NULL,
  contact_number text NOT NULL,
  address text NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  updated_by uuid REFERENCES profiles(id)
);

-- Password reset tokens table
CREATE TABLE IF NOT EXISTS password_reset_tokens (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text NOT NULL,
  token text NOT NULL UNIQUE,
  expires_at timestamptz NOT NULL,
  used boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);

-- Create indexes
CREATE INDEX IF NOT EXISTS idx_profiles_role ON profiles(role);
CREATE INDEX IF NOT EXISTS idx_profiles_email ON profiles(email);
CREATE INDEX IF NOT EXISTS idx_clients_user_id ON clients(user_id);
CREATE INDEX IF NOT EXISTS idx_sites_client_id ON sites(client_id);
CREATE INDEX IF NOT EXISTS idx_engineer_assignments_engineer_id ON engineer_assignments(engineer_id);
CREATE INDEX IF NOT EXISTS idx_engineer_assignments_client_id ON engineer_assignments(client_id);
CREATE INDEX IF NOT EXISTS idx_engineer_assignments_site_id ON engineer_assignments(site_id);
CREATE INDEX IF NOT EXISTS idx_check_ins_engineer_id ON check_ins(engineer_id);
CREATE INDEX IF NOT EXISTS idx_check_ins_date ON check_ins(date);
CREATE INDEX IF NOT EXISTS idx_check_ins_engineer_date ON check_ins(engineer_id, date DESC);
CREATE INDEX IF NOT EXISTS idx_daily_reports_engineer_id ON daily_reports(engineer_id);
CREATE INDEX IF NOT EXISTS idx_daily_reports_client_id ON daily_reports(client_id);
CREATE INDEX IF NOT EXISTS idx_daily_reports_site_id ON daily_reports(site_id);
CREATE INDEX IF NOT EXISTS idx_daily_reports_report_date ON daily_reports(report_date);
CREATE INDEX IF NOT EXISTS idx_daily_reports_engineer_report_date ON daily_reports(engineer_id, report_date DESC);
CREATE INDEX IF NOT EXISTS idx_leave_requests_engineer_id ON leave_requests(engineer_id);
CREATE INDEX IF NOT EXISTS idx_leave_requests_status ON leave_requests(status);
CREATE INDEX IF NOT EXISTS idx_leave_requests_approved_by ON leave_requests(approved_by);
CREATE INDEX IF NOT EXISTS idx_leave_requests_backup_engineer_id ON leave_requests(backup_engineer_id);
CREATE INDEX IF NOT EXISTS idx_leave_requests_engineer_status_v2 ON leave_requests(engineer_id, status);
CREATE INDEX IF NOT EXISTS idx_notifications_user_id ON notifications(user_id);
CREATE INDEX IF NOT EXISTS idx_password_reset_tokens_email ON password_reset_tokens(email);
CREATE INDEX IF NOT EXISTS idx_password_reset_tokens_token ON password_reset_tokens(token);
CREATE INDEX IF NOT EXISTS idx_password_reset_tokens_expires_at ON password_reset_tokens(expires_at);
CREATE INDEX IF NOT EXISTS idx_engineer_assignments_active ON engineer_assignments(engineer_id, is_active) WHERE is_active = true;
