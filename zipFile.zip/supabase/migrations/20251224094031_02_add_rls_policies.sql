/*
  # Add Row Level Security Policies
  
  Enables RLS and adds security policies for all tables.
  
  Security Model:
  - Admin and HR: Full access to all data
  - Engineers: Access to own data and assigned clients
  - Clients: Access to their own data and assigned engineers
*/

-- Enable RLS on all tables
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE clients ENABLE ROW LEVEL SECURITY;
ALTER TABLE sites ENABLE ROW LEVEL SECURITY;
ALTER TABLE engineer_assignments ENABLE ROW LEVEL SECURITY;
ALTER TABLE check_ins ENABLE ROW LEVEL SECURITY;
ALTER TABLE daily_reports ENABLE ROW LEVEL SECURITY;
ALTER TABLE leave_requests ENABLE ROW LEVEL SECURITY;
ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;
ALTER TABLE email_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE company_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE password_reset_tokens ENABLE ROW LEVEL SECURITY;

-- PROFILES policies
CREATE POLICY "Admin and HR can view all profiles"
  ON profiles FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles p
      WHERE p.id = auth.uid()
      AND p.role IN ('admin', 'hr')
    )
  );

CREATE POLICY "Users can view own profile"
  ON profiles FOR SELECT
  TO authenticated
  USING (id = auth.uid());

CREATE POLICY "Admin and HR can update all profiles"
  ON profiles FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles p
      WHERE p.id = auth.uid()
      AND p.role IN ('admin', 'hr')
    )
  );

CREATE POLICY "Users can update own profile"
  ON profiles FOR UPDATE
  TO authenticated
  USING (id = auth.uid())
  WITH CHECK (id = auth.uid());

CREATE POLICY "Admin can insert profiles"
  ON profiles FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM profiles p
      WHERE p.id = auth.uid()
      AND p.role = 'admin'
    )
  );

-- CLIENTS policies
CREATE POLICY "Admin and HR can view all clients"
  ON clients FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles p
      WHERE p.id = auth.uid()
      AND p.role IN ('admin', 'hr')
    )
  );

CREATE POLICY "Engineers can view their assigned clients"
  ON clients FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'engineer'
      AND EXISTS (
        SELECT 1 FROM engineer_assignments
        WHERE engineer_assignments.engineer_id = auth.uid()
        AND engineer_assignments.client_id = clients.id
        AND engineer_assignments.is_active = true
      )
    )
  );

CREATE POLICY "Clients can view own client record"
  ON clients FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "Admin and HR can manage clients"
  ON clients FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles p
      WHERE p.id = auth.uid()
      AND p.role IN ('admin', 'hr')
    )
  );

-- SITES policies
CREATE POLICY "Admin and HR can view all sites"
  ON sites FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles p
      WHERE p.id = auth.uid()
      AND p.role IN ('admin', 'hr')
    )
  );

CREATE POLICY "Engineers can view their assigned sites"
  ON sites FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.role = 'engineer'
      AND EXISTS (
        SELECT 1 FROM engineer_assignments
        WHERE engineer_assignments.engineer_id = auth.uid()
        AND engineer_assignments.site_id = sites.id
        AND engineer_assignments.is_active = true
      )
    )
  );

CREATE POLICY "Clients can view own sites"
  ON sites FOR SELECT
  TO authenticated
  USING (
    client_id IN (
      SELECT id FROM clients WHERE user_id = auth.uid()
    )
  );

CREATE POLICY "Admin and HR can manage sites"
  ON sites FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles p
      WHERE p.id = auth.uid()
      AND p.role IN ('admin', 'hr')
    )
  );

-- ENGINEER_ASSIGNMENTS policies
CREATE POLICY "Admin and HR can view all assignments"
  ON engineer_assignments FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles p
      WHERE p.id = auth.uid()
      AND p.role IN ('admin', 'hr')
    )
  );

CREATE POLICY "Engineers can view own assignments"
  ON engineer_assignments FOR SELECT
  TO authenticated
  USING (engineer_id = auth.uid());

CREATE POLICY "Clients can view their assignments"
  ON engineer_assignments FOR SELECT
  TO authenticated
  USING (
    client_id IN (
      SELECT id FROM clients WHERE user_id = auth.uid()
    )
  );

CREATE POLICY "Admin and HR can manage assignments"
  ON engineer_assignments FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles p
      WHERE p.id = auth.uid()
      AND p.role IN ('admin', 'hr')
    )
  );

-- CHECK_INS policies
CREATE POLICY "Admin and HR can view all check-ins"
  ON check_ins FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles p
      WHERE p.id = auth.uid()
      AND p.role IN ('admin', 'hr')
    )
  );

CREATE POLICY "Engineers can view own check-ins"
  ON check_ins FOR SELECT
  TO authenticated
  USING (engineer_id = auth.uid());

CREATE POLICY "Clients can view their engineers' check-ins"
  ON check_ins FOR SELECT
  TO authenticated
  USING (
    engineer_id IN (
      SELECT engineer_id FROM engineer_assignments
      WHERE client_id IN (
        SELECT id FROM clients WHERE user_id = auth.uid()
      )
      AND is_active = true
    )
  );

CREATE POLICY "Engineers can insert own check-ins"
  ON check_ins FOR INSERT
  TO authenticated
  WITH CHECK (engineer_id = auth.uid());

CREATE POLICY "Engineers can update own check-ins"
  ON check_ins FOR UPDATE
  TO authenticated
  USING (engineer_id = auth.uid())
  WITH CHECK (engineer_id = auth.uid());

-- DAILY_REPORTS policies
CREATE POLICY "Admin and HR can view all reports"
  ON daily_reports FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles p
      WHERE p.id = auth.uid()
      AND p.role IN ('admin', 'hr')
    )
  );

CREATE POLICY "Engineers can view own reports"
  ON daily_reports FOR SELECT
  TO authenticated
  USING (engineer_id = auth.uid());

CREATE POLICY "Clients can view their reports"
  ON daily_reports FOR SELECT
  TO authenticated
  USING (
    client_id IN (
      SELECT id FROM clients WHERE user_id = auth.uid()
    )
  );

CREATE POLICY "Engineers can insert own reports"
  ON daily_reports FOR INSERT
  TO authenticated
  WITH CHECK (engineer_id = auth.uid());

CREATE POLICY "Engineers can update own reports"
  ON daily_reports FOR UPDATE
  TO authenticated
  USING (engineer_id = auth.uid())
  WITH CHECK (engineer_id = auth.uid());

CREATE POLICY "Admin and HR can update all reports"
  ON daily_reports FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles p
      WHERE p.id = auth.uid()
      AND p.role IN ('admin', 'hr')
    )
  );

-- LEAVE_REQUESTS policies
CREATE POLICY "Admin and HR can view all leave requests"
  ON leave_requests FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles p
      WHERE p.id = auth.uid()
      AND p.role IN ('admin', 'hr')
    )
  );

CREATE POLICY "Engineers can view own leave requests"
  ON leave_requests FOR SELECT
  TO authenticated
  USING (engineer_id = auth.uid());

CREATE POLICY "Clients can view leave requests for their engineers"
  ON leave_requests FOR SELECT
  TO authenticated
  USING (
    engineer_id IN (
      SELECT engineer_id FROM engineer_assignments
      WHERE client_id IN (
        SELECT id FROM clients WHERE user_id = auth.uid()
      )
      AND is_active = true
    )
  );

CREATE POLICY "Engineers can insert own leave requests"
  ON leave_requests FOR INSERT
  TO authenticated
  WITH CHECK (engineer_id = auth.uid());

CREATE POLICY "Admin and HR can update leave requests"
  ON leave_requests FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles p
      WHERE p.id = auth.uid()
      AND p.role IN ('admin', 'hr')
    )
  );

-- NOTIFICATIONS policies
CREATE POLICY "Users can view own notifications"
  ON notifications FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "Users can update own notifications"
  ON notifications FOR UPDATE
  TO authenticated
  USING (user_id = auth.uid())
  WITH CHECK (user_id = auth.uid());

CREATE POLICY "System can insert notifications"
  ON notifications FOR INSERT
  TO authenticated
  WITH CHECK (true);

-- EMAIL_LOGS policies
CREATE POLICY "Admin and HR can view email logs"
  ON email_logs FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles p
      WHERE p.id = auth.uid()
      AND p.role IN ('admin', 'hr')
    )
  );

CREATE POLICY "System can insert email logs"
  ON email_logs FOR INSERT
  TO authenticated
  WITH CHECK (true);

-- COMPANY_PROFILES policies
CREATE POLICY "Everyone can view company profiles"
  ON company_profiles FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Admin can manage company profiles"
  ON company_profiles FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles p
      WHERE p.id = auth.uid()
      AND p.role = 'admin'
    )
  );

-- PASSWORD_RESET_TOKENS policies
CREATE POLICY "Users can view own reset tokens"
  ON password_reset_tokens FOR SELECT
  TO authenticated
  USING (email = (
    SELECT email FROM profiles WHERE id = auth.uid()
  ));

CREATE POLICY "Public can create reset tokens"
  ON password_reset_tokens FOR INSERT
  TO anon
  WITH CHECK (true);

CREATE POLICY "Users can delete own reset tokens"
  ON password_reset_tokens FOR DELETE
  TO authenticated
  USING (email = (
    SELECT email FROM profiles WHERE id = auth.uid()
  ));
