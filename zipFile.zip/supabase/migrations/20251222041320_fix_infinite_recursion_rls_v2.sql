/*
  # Fix Infinite Recursion in RLS Policies

  ## Problem
  Policies that check user role by querying profiles table create infinite recursion
  because querying profiles requires passing RLS checks, which query profiles again.

  ## Solution
  1. Ensure users can always read their own profile (base case, no recursion)
  2. Use security definer functions for role checks to bypass RLS
  3. Simplify admin/HR policies

  ## Changes Made
  - Drop all existing conflicting policies
  - Create simple, non-recursive policies
  - Use security definer function in public schema
*/

-- ============================================================================
-- DROP ALL EXISTING POLICIES ON PROFILES
-- ============================================================================

DROP POLICY IF EXISTS "Users can view own profile" ON public.profiles;
DROP POLICY IF EXISTS "Users can update own profile" ON public.profiles;
DROP POLICY IF EXISTS "Users can read own profile" ON public.profiles;
DROP POLICY IF EXISTS "Admin and HR can view all profiles" ON public.profiles;
DROP POLICY IF EXISTS "Admin and HR can view all profiles v3" ON public.profiles;
DROP POLICY IF EXISTS "Admin can manage profiles v3" ON public.profiles;
DROP POLICY IF EXISTS "Admin can view all profiles v2" ON public.profiles;
DROP POLICY IF EXISTS "Admin can read all profiles" ON public.profiles;
DROP POLICY IF EXISTS "HR can read engineer profiles" ON public.profiles;
DROP POLICY IF EXISTS "HR can view all profiles v2" ON public.profiles;
DROP POLICY IF EXISTS "Admin can insert profiles v2" ON public.profiles;
DROP POLICY IF EXISTS "Admin can update all profiles v2" ON public.profiles;

-- ============================================================================
-- CREATE HELPER FUNCTION FOR ROLE CHECK (SECURITY DEFINER)
-- ============================================================================

DROP FUNCTION IF EXISTS public.current_user_role();

CREATE OR REPLACE FUNCTION public.current_user_role()
RETURNS text
LANGUAGE sql
SECURITY DEFINER
STABLE
SET search_path = public
AS $$
  SELECT role FROM public.profiles WHERE id = auth.uid() LIMIT 1;
$$;

GRANT EXECUTE ON FUNCTION public.current_user_role() TO authenticated;

-- ============================================================================
-- CREATE NEW NON-RECURSIVE POLICIES FOR PROFILES
-- ============================================================================

-- Base case: Users can ALWAYS view their own profile (prevents recursion)
CREATE POLICY "Users can view own profile"
  ON public.profiles
  FOR SELECT
  TO authenticated
  USING (id = auth.uid());

-- Users can update their own profile
CREATE POLICY "Users can update own profile"
  ON public.profiles
  FOR UPDATE
  TO authenticated
  USING (id = auth.uid())
  WITH CHECK (id = auth.uid());

-- Admin and HR can view all profiles (using security definer function)
CREATE POLICY "Admin and HR can view all profiles"
  ON public.profiles
  FOR SELECT
  TO authenticated
  USING (current_user_role() IN ('admin', 'hr'));

-- Admin can insert new profiles
CREATE POLICY "Admin can insert profiles"
  ON public.profiles
  FOR INSERT
  TO authenticated
  WITH CHECK (current_user_role() = 'admin');

-- Admin can update any profile
CREATE POLICY "Admin can update any profile"
  ON public.profiles
  FOR UPDATE
  TO authenticated
  USING (current_user_role() = 'admin')
  WITH CHECK (current_user_role() = 'admin');

-- Admin can delete profiles
CREATE POLICY "Admin can delete profiles"
  ON public.profiles
  FOR DELETE
  TO authenticated
  USING (current_user_role() = 'admin');

-- ============================================================================
-- UPDATE OTHER TABLES TO USE SECURITY DEFINER FUNCTION
-- ============================================================================

-- CLIENTS TABLE
DROP POLICY IF EXISTS "Admin and HR can view all clients v3" ON public.clients;
DROP POLICY IF EXISTS "Admin can manage clients v3" ON public.clients;
DROP POLICY IF EXISTS "Admin and HR can view all clients" ON public.clients;
DROP POLICY IF EXISTS "Admin can manage clients" ON public.clients;

CREATE POLICY "Admin and HR can view all clients"
  ON public.clients
  FOR SELECT
  TO authenticated
  USING (current_user_role() IN ('admin', 'hr'));

CREATE POLICY "Admin can manage clients"
  ON public.clients
  FOR ALL
  TO authenticated
  USING (current_user_role() = 'admin')
  WITH CHECK (current_user_role() = 'admin');

-- SITES TABLE
DROP POLICY IF EXISTS "Admin and HR can view all sites v3" ON public.sites;
DROP POLICY IF EXISTS "Admin can manage sites v3" ON public.sites;
DROP POLICY IF EXISTS "Admin and HR can view all sites" ON public.sites;
DROP POLICY IF EXISTS "Admin can manage sites" ON public.sites;

CREATE POLICY "Admin and HR can view all sites"
  ON public.sites
  FOR SELECT
  TO authenticated
  USING (current_user_role() IN ('admin', 'hr'));

CREATE POLICY "Admin can manage sites"
  ON public.sites
  FOR ALL
  TO authenticated
  USING (current_user_role() = 'admin')
  WITH CHECK (current_user_role() = 'admin');

-- ENGINEER ASSIGNMENTS TABLE
DROP POLICY IF EXISTS "Admin and HR can view all assignments v3" ON public.engineer_assignments;
DROP POLICY IF EXISTS "Admin can manage assignments v3" ON public.engineer_assignments;
DROP POLICY IF EXISTS "Admin and HR can view all assignments" ON public.engineer_assignments;
DROP POLICY IF EXISTS "Admin can manage assignments" ON public.engineer_assignments;

CREATE POLICY "Admin and HR can view all assignments"
  ON public.engineer_assignments
  FOR SELECT
  TO authenticated
  USING (current_user_role() IN ('admin', 'hr'));

CREATE POLICY "Admin can manage assignments"
  ON public.engineer_assignments
  FOR ALL
  TO authenticated
  USING (current_user_role() = 'admin')
  WITH CHECK (current_user_role() = 'admin');

-- CHECK-INS TABLE
DROP POLICY IF EXISTS "Admin and HR can view all check-ins v3" ON public.check_ins;
DROP POLICY IF EXISTS "Admin and HR can view all check-ins" ON public.check_ins;

CREATE POLICY "Admin and HR can view all check-ins"
  ON public.check_ins
  FOR SELECT
  TO authenticated
  USING (current_user_role() IN ('admin', 'hr'));

-- DAILY REPORTS TABLE
DROP POLICY IF EXISTS "Admin and HR can view all reports v3" ON public.daily_reports;
DROP POLICY IF EXISTS "Admin and HR can view all reports" ON public.daily_reports;

CREATE POLICY "Admin and HR can view all reports"
  ON public.daily_reports
  FOR SELECT
  TO authenticated
  USING (current_user_role() IN ('admin', 'hr'));

-- LEAVE REQUESTS TABLE
DROP POLICY IF EXISTS "Admin and HR can view all leave requests v3" ON public.leave_requests;
DROP POLICY IF EXISTS "Admin and HR can update leave requests v3" ON public.leave_requests;
DROP POLICY IF EXISTS "Admin and HR can view all leave requests" ON public.leave_requests;
DROP POLICY IF EXISTS "Admin and HR can update leave requests" ON public.leave_requests;

CREATE POLICY "Admin and HR can view all leave requests"
  ON public.leave_requests
  FOR SELECT
  TO authenticated
  USING (current_user_role() IN ('admin', 'hr'));

CREATE POLICY "Admin and HR can update leave requests"
  ON public.leave_requests
  FOR UPDATE
  TO authenticated
  USING (current_user_role() IN ('admin', 'hr'))
  WITH CHECK (current_user_role() IN ('admin', 'hr'));

-- EMAIL LOGS TABLE
DROP POLICY IF EXISTS "Admin and HR can view email logs v3" ON public.email_logs;
DROP POLICY IF EXISTS "Admin and HR can view email logs" ON public.email_logs;

CREATE POLICY "Admin and HR can view email logs"
  ON public.email_logs
  FOR SELECT
  TO authenticated
  USING (current_user_role() IN ('admin', 'hr'));

-- NOTIFICATIONS TABLE
DROP POLICY IF EXISTS "Admin and HR can view all notifications v3" ON public.notifications;
DROP POLICY IF EXISTS "Admin and HR can view all notifications" ON public.notifications;

CREATE POLICY "Admin and HR can view all notifications"
  ON public.notifications
  FOR SELECT
  TO authenticated
  USING (current_user_role() IN ('admin', 'hr'));

-- ============================================================================
-- COMPLETION
-- ============================================================================

DO $$
BEGIN
  RAISE NOTICE 'Infinite recursion fix applied successfully';
  RAISE NOTICE 'Created current_user_role() security definer function';
  RAISE NOTICE 'All policies now use non-recursive role checks';
  RAISE NOTICE 'Users can always view their own profile (base case)';
END $$;
