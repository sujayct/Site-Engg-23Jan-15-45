/*
  # Simplify Admin/HR RLS Policies

  ## Overview
  Simplifies RLS policies by directly checking the user's role from the profiles table
  instead of using the get_user_role() function, which may have context issues.

  ## Changes Made
  - Drop policies that use get_user_role()
  - Create simpler policies with direct role checks
*/

-- ============================================================================
-- PROFILES TABLE
-- ============================================================================

DROP POLICY IF EXISTS "Admin can view all profiles v2" ON public.profiles;
DROP POLICY IF EXISTS "HR can view all profiles v2" ON public.profiles;
DROP POLICY IF EXISTS "Admin can insert profiles v2" ON public.profiles;
DROP POLICY IF EXISTS "Admin can update all profiles v2" ON public.profiles;

CREATE POLICY "Admin and HR can view all profiles v3"
  ON public.profiles
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.profiles p
      WHERE p.id = auth.uid()
      AND p.role IN ('admin', 'hr')
    )
  );

CREATE POLICY "Admin can manage profiles v3"
  ON public.profiles
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.profiles p
      WHERE p.id = auth.uid()
      AND p.role = 'admin'
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.profiles p
      WHERE p.id = auth.uid()
      AND p.role = 'admin'
    )
  );

-- ============================================================================
-- CLIENTS TABLE
-- ============================================================================

DROP POLICY IF EXISTS "Admin can view all clients v2" ON public.clients;
DROP POLICY IF EXISTS "Admin can manage clients v2" ON public.clients;
DROP POLICY IF EXISTS "HR can view all clients v2" ON public.clients;

CREATE POLICY "Admin and HR can view all clients v3"
  ON public.clients
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.profiles
      WHERE id = auth.uid()
      AND role IN ('admin', 'hr')
    )
  );

CREATE POLICY "Admin can manage clients v3"
  ON public.clients
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.profiles
      WHERE id = auth.uid()
      AND role = 'admin'
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.profiles
      WHERE id = auth.uid()
      AND role = 'admin'
    )
  );

-- ============================================================================
-- SITES TABLE
-- ============================================================================

DROP POLICY IF EXISTS "Admin can view all sites v2" ON public.sites;
DROP POLICY IF EXISTS "Admin can manage sites v2" ON public.sites;
DROP POLICY IF EXISTS "HR can view all sites v2" ON public.sites;

CREATE POLICY "Admin and HR can view all sites v3"
  ON public.sites
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.profiles
      WHERE id = auth.uid()
      AND role IN ('admin', 'hr')
    )
  );

CREATE POLICY "Admin can manage sites v3"
  ON public.sites
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.profiles
      WHERE id = auth.uid()
      AND role = 'admin'
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.profiles
      WHERE id = auth.uid()
      AND role = 'admin'
    )
  );

-- ============================================================================
-- ENGINEER ASSIGNMENTS TABLE
-- ============================================================================

DROP POLICY IF EXISTS "Admin can view all assignments v2" ON public.engineer_assignments;
DROP POLICY IF EXISTS "Admin can manage assignments v2" ON public.engineer_assignments;
DROP POLICY IF EXISTS "HR can view all assignments v2" ON public.engineer_assignments;

CREATE POLICY "Admin and HR can view all assignments v3"
  ON public.engineer_assignments
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.profiles
      WHERE id = auth.uid()
      AND role IN ('admin', 'hr')
    )
  );

CREATE POLICY "Admin can manage assignments v3"
  ON public.engineer_assignments
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.profiles
      WHERE id = auth.uid()
      AND role = 'admin'
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.profiles
      WHERE id = auth.uid()
      AND role = 'admin'
    )
  );

-- ============================================================================
-- CHECK-INS TABLE
-- ============================================================================

DROP POLICY IF EXISTS "Admin can view all check-ins v2" ON public.check_ins;
DROP POLICY IF EXISTS "HR can view all check-ins v2" ON public.check_ins;

CREATE POLICY "Admin and HR can view all check-ins v3"
  ON public.check_ins
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.profiles
      WHERE id = auth.uid()
      AND role IN ('admin', 'hr')
    )
  );

-- ============================================================================
-- DAILY REPORTS TABLE
-- ============================================================================

DROP POLICY IF EXISTS "Admin can view all reports v2" ON public.daily_reports;
DROP POLICY IF EXISTS "HR can view all reports v2" ON public.daily_reports;

CREATE POLICY "Admin and HR can view all reports v3"
  ON public.daily_reports
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.profiles
      WHERE id = auth.uid()
      AND role IN ('admin', 'hr')
    )
  );

-- ============================================================================
-- LEAVE REQUESTS TABLE
-- ============================================================================

DROP POLICY IF EXISTS "Admin can view all leave requests v2" ON public.leave_requests;
DROP POLICY IF EXISTS "HR can view all leave requests v2" ON public.leave_requests;
DROP POLICY IF EXISTS "HR can update leave requests v2" ON public.leave_requests;

CREATE POLICY "Admin and HR can view all leave requests v3"
  ON public.leave_requests
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.profiles
      WHERE id = auth.uid()
      AND role IN ('admin', 'hr')
    )
  );

CREATE POLICY "Admin and HR can update leave requests v3"
  ON public.leave_requests
  FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.profiles
      WHERE id = auth.uid()
      AND role IN ('admin', 'hr')
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.profiles
      WHERE id = auth.uid()
      AND role IN ('admin', 'hr')
    )
  );

-- ============================================================================
-- EMAIL LOGS TABLE
-- ============================================================================

DROP POLICY IF EXISTS "Admin can view email logs v2" ON public.email_logs;

CREATE POLICY "Admin and HR can view email logs v3"
  ON public.email_logs
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.profiles
      WHERE id = auth.uid()
      AND role IN ('admin', 'hr')
    )
  );

-- ============================================================================
-- NOTIFICATIONS TABLE
-- ============================================================================

DROP POLICY IF EXISTS "Admin can view all notifications" ON public.notifications;

CREATE POLICY "Admin and HR can view all notifications v3"
  ON public.notifications
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.profiles
      WHERE id = auth.uid()
      AND role IN ('admin', 'hr')
    )
  );

-- ============================================================================
-- COMPLETION
-- ============================================================================

DO $$
BEGIN
  RAISE NOTICE 'Simplified Admin/HR RLS policies applied successfully';
  RAISE NOTICE 'All policies now use direct role checks instead of get_user_role()';
END $$;
