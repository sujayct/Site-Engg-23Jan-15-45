/*
  # Add Designation Field for Engineers

  1. Changes
    - Add `designation` column to `profiles` table
    - This field stores the job title/designation for engineers
    - Mandatory field for engineers (e.g., "Senior Engineer", "Junior Engineer", "Lead Technician")
    - Editable by Admin and HR roles
    - Visible in HR dashboards, client dashboards, and reports

  2. Details
    - Column: `designation` (text, nullable for backward compatibility)
    - Default value: 'Engineer' for existing records
    - Visible across all dashboards where engineer information is displayed
*/

-- Add designation column to profiles table
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'profiles' AND column_name = 'designation'
  ) THEN
    ALTER TABLE profiles ADD COLUMN designation text;
  END IF;
END $$;

-- Set default designation for existing engineer profiles
UPDATE profiles 
SET designation = CASE 
  WHEN role = 'engineer' THEN 'Engineer'
  ELSE NULL
END
WHERE designation IS NULL;
