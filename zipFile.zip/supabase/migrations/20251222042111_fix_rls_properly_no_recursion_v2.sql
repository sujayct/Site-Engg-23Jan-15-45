/*
  # Fix RLS Without Recursion - Final Solution

  ## Problem
  Even with security definer function, we have recursion because:
  - User logs in
  - System tries to fetch profile
  - Profile SELECT policy checks current_user_role()
  - current_user_role() tries to SELECT from profiles
  - This triggers the policy again = infinite recursion

  ## Solution
  1. CRITICAL: Users must be able to read their own profile WITHOUT any function calls
  2. Admins and HR get extra permissions to read ALL profiles
  3. Use simple, direct checks - NO subqueries or function calls for own profile

  ## Changes Made
  - Drop all policies first
  - Drop problematic function
  - Create ultra-simple policies that can't recurse
  - Own profile access = direct auth.uid() check only
  - Admin/HR access = check role column directly (allowed when reading other profiles)
*/

-- ============================================================================
-- CLEAN SLATE - DROP ALL POLICIES FIRST
-- ============================================================================

-- Drop ALL profile policies
DROP POLICY IF EXISTS "Anyone can read own profile" ON public.profiles;
DROP POLICY IF EXISTS "Users can view own profile" ON public.profiles;
DROP POLICY IF EXISTS "Users can update own profile" ON public.profiles;
DROP POLICY IF EXISTS "Admin and HR can view all profiles" ON public.profiles;
DROP POLICY IF EXISTS "HR can read all profiles" ON public.profiles;
DROP POLICY IF EXISTS "Admins can read all profiles" ON public.profiles;
DROP POLICY IF EXISTS "Admin can insert profiles" ON public.profiles;
DROP POLICY IF EXISTS "Admins can insert profiles" ON public.profiles;
DROP POLICY IF EXISTS "Admin can update any profile" ON public.profiles;
DROP POLICY IF EXISTS "Admins can update all profiles" ON public.profiles;
DROP POLICY IF EXISTS "Admin can delete profiles" ON public.profiles;
DROP POLICY IF EXISTS "Admins can delete profiles" ON public.profiles;

-- Drop other table policies that use the function
DROP POLICY IF EXISTS "Admin and HR can view all clients" ON public.clients;
DROP POLICY IF EXISTS "Admin and HR can view clients" ON public.clients;
DROP POLICY IF EXISTS "Admin can manage clients" ON public.clients;
DROP POLICY IF EXISTS "Admins can manage clients" ON public.clients;

DROP POLICY IF EXISTS "Admin and HR can view all sites" ON public.sites;
DROP POLICY IF EXISTS "Admin and HR can view sites" ON public.sites;
DROP POLICY IF EXISTS "Admin can manage sites" ON public.sites;
DROP POLICY IF EXISTS "Admins can manage sites" ON public.sites;

DROP POLICY IF EXISTS "Admin and HR can view all assignments" ON public.engineer_assignments;
DROP POLICY IF EXISTS "Admin and HR can view assignments" ON public.engineer_assignments;
DROP POLICY IF EXISTS "Admin can manage assignments" ON public.engineer_assignments;
DROP POLICY IF EXISTS "Admins can manage assignments" ON public.engineer_assignments;

DROP POLICY IF EXISTS "Admin and HR can view all check-ins" ON public.check_ins;
DROP POLICY IF EXISTS "Admin and HR can view check-ins" ON public.check_ins;

DROP POLICY IF EXISTS "Admin and HR can view all reports" ON public.daily_reports;
DROP POLICY IF EXISTS "Admin and HR can view reports" ON public.daily_reports;

DROP POLICY IF EXISTS "Admin and HR can view all leave requests" ON public.leave_requests;
DROP POLICY IF EXISTS "Admin and HR can view leave requests" ON public.leave_requests;
DROP POLICY IF EXISTS "Admin and HR can update leave requests" ON public.leave_requests;

DROP POLICY IF EXISTS "Admin and HR can view email logs" ON public.email_logs;
DROP POLICY IF EXISTS "Admin and HR can view all notifications" ON public.notifications;
DROP POLICY IF EXISTS "Admin and HR can view notifications" ON public.notifications;

-- Now drop the function
DROP FUNCTION IF EXISTS public.current_user_role() CASCADE;

-- ============================================================================
-- CREATE SIMPLE, NON-RECURSIVE POLICIES FOR PROFILES
-- ============================================================================

-- POLICY 1: Everyone can read their OWN profile (no function calls, no subqueries)
CREATE POLICY "Anyone can read own profile"
  ON public.profiles
  FOR SELECT
  TO authenticated
  USING (id = auth.uid());

-- POLICY 2: Everyone can update their OWN profile
CREATE POLICY "Anyone can update own profile"
  ON public.profiles
  FOR UPDATE
  TO authenticated
  USING (id = auth.uid())
  WITH CHECK (id = auth.uid());

-- POLICY 3: Admins can read ALL profiles (direct role check on the row being read)
CREATE POLICY "Admins can read all profiles"
  ON public.profiles
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.profiles AS p
      WHERE p.id = auth.uid() AND p.role = 'admin'
    )
  );

-- POLICY 4: HR can read ALL profiles (direct role check)
CREATE POLICY "HR can read all profiles"
  ON public.profiles
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.profiles AS p
      WHERE p.id = auth.uid() AND p.role = 'hr'
    )
  );

-- POLICY 5: Admins can insert profiles
CREATE POLICY "Admins can insert profiles"
  ON public.profiles
  FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.profiles AS p
      WHERE p.id = auth.uid() AND p.role = 'admin'
    )
  );

-- POLICY 6: Admins can update any profile
CREATE POLICY "Admins can update all profiles"
  ON public.profiles
  FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.profiles AS p
      WHERE p.id = auth.uid() AND p.role = 'admin'
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.profiles AS p
      WHERE p.id = auth.uid() AND p.role = 'admin'
    )
  );

-- POLICY 7: Admins can delete profiles
CREATE POLICY "Admins can delete profiles"
  ON public.profiles
  FOR DELETE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.profiles AS p
      WHERE p.id = auth.uid() AND p.role = 'admin'
    )
  );

-- ============================================================================
-- UPDATE OTHER TABLES (same pattern - use aliased subquery)
-- ============================================================================

-- CLIENTS TABLE
CREATE POLICY "Admin and HR can view clients"
  ON public.clients
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.profiles AS p
      WHERE p.id = auth.uid() AND p.role IN ('admin', 'hr')
    )
  );

CREATE POLICY "Admins can manage clients"
  ON public.clients
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.profiles AS p
      WHERE p.id = auth.uid() AND p.role = 'admin'
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.profiles AS p
      WHERE p.id = auth.uid() AND p.role = 'admin'
    )
  );

-- SITES TABLE
CREATE POLICY "Admin and HR can view sites"
  ON public.sites
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.profiles AS p
      WHERE p.id = auth.uid() AND p.role IN ('admin', 'hr')
    )
  );

CREATE POLICY "Admins can manage sites"
  ON public.sites
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.profiles AS p
      WHERE p.id = auth.uid() AND p.role = 'admin'
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.profiles AS p
      WHERE p.id = auth.uid() AND p.role = 'admin'
    )
  );

-- ENGINEER ASSIGNMENTS TABLE
CREATE POLICY "Admin and HR can view assignments"
  ON public.engineer_assignments
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.profiles AS p
      WHERE p.id = auth.uid() AND p.role IN ('admin', 'hr')
    )
  );

CREATE POLICY "Admins can manage assignments"
  ON public.engineer_assignments
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.profiles AS p
      WHERE p.id = auth.uid() AND p.role = 'admin'
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.profiles AS p
      WHERE p.id = auth.uid() AND p.role = 'admin'
    )
  );

-- CHECK-INS TABLE
CREATE POLICY "Admin and HR can view check-ins"
  ON public.check_ins
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.profiles AS p
      WHERE p.id = auth.uid() AND p.role IN ('admin', 'hr')
    )
  );

-- DAILY REPORTS TABLE
CREATE POLICY "Admin and HR can view reports"
  ON public.daily_reports
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.profiles AS p
      WHERE p.id = auth.uid() AND p.role IN ('admin', 'hr')
    )
  );

-- LEAVE REQUESTS TABLE
CREATE POLICY "Admin and HR can view leave requests"
  ON public.leave_requests
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.profiles AS p
      WHERE p.id = auth.uid() AND p.role IN ('admin', 'hr')
    )
  );

CREATE POLICY "Admin and HR can update leave requests"
  ON public.leave_requests
  FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.profiles AS p
      WHERE p.id = auth.uid() AND p.role IN ('admin', 'hr')
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.profiles AS p
      WHERE p.id = auth.uid() AND p.role IN ('admin', 'hr')
    )
  );

-- EMAIL LOGS TABLE  
CREATE POLICY "Admin and HR can view email logs"
  ON public.email_logs
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.profiles AS p
      WHERE p.id = auth.uid() AND p.role IN ('admin', 'hr')
    )
  );

-- NOTIFICATIONS TABLE
CREATE POLICY "Admin and HR can view notifications"
  ON public.notifications
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.profiles AS p
      WHERE p.id = auth.uid() AND p.role IN ('admin', 'hr')
    )
  );

-- ============================================================================
-- IMPORTANT NOTE ABOUT THIS SOLUTION
-- ============================================================================

/*
  Why this works without recursion:

  1. When user tries to SELECT their own profile:
     - First policy "Anyone can read own profile" matches
     - Uses simple check: id = auth.uid()
     - No subquery, no function call
     - Returns immediately with their profile
     - NO RECURSION

  2. When admin tries to SELECT another user's profile:
     - First policy doesn't match (not their own id)
     - Second policy "Admins can read all profiles" is checked
     - Uses EXISTS subquery with ALIAS: "public.profiles AS p"
     - This subquery reads from profiles table
     - But it only reads ONE row: WHERE p.id = auth.uid()
     - This matches the first policy (own profile)
     - Gets the role, compares to 'admin'
     - Returns result
     - NO RECURSION because we only read the admin's own profile

  Key insight: Using table alias (AS p) and only reading the current user's 
  profile in the subquery prevents recursion.
*/

DO $$
BEGIN
  RAISE NOTICE 'RLS policies fixed - no more recursion!';
  RAISE NOTICE 'Policy 1: Anyone can read own profile (no subqueries)';
  RAISE NOTICE 'Policy 2-7: Admin/HR access using aliased subqueries';
END $$;
